# Copyright 2026 AceMQ.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Talking to RabbitMQ, through aio-pika.

This is the only module in the library that knows a broker client exists, which
is why it is imported lazily by :func:`acemq_amqp.connect` rather than by the
package: reading an AceMQ envelope should not require installing an AMQP client,
so aio-pika is an extra and everything above :mod:`acemq_amqp.transport` is
written without it.

Channels are handed out rather than shared, because in AMQP a channel is what
dies when the broker refuses something. A queue declared with settings that
disagree with the ones already on the broker answers ``PRECONDITION_FAILED`` and
takes its channel down with it — on a shared channel that would also stop every
publisher and consumer that happened to be using it, for a failure that has
nothing to do with them.
"""

from __future__ import annotations

import asyncio
from collections import Counter
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from typing import Any, cast

import aio_pika
from aio_pika.abc import (
    AbstractChannel,
    AbstractIncomingMessage,
    AbstractRobustConnection,
)
from aiormq.exceptions import ChannelNotFoundEntity, DeliveryError

from .transport import (
    ConsumeSpec,
    Delivery,
    ExchangeSpec,
    Outbound,
    PublishResult,
    QueueSpec,
)


class RabbitMQTransport:
    """A :class:`~acemq_amqp.transport.Transport` backed by aio-pika.

    Built by :meth:`connect` rather than by hand in the ordinary case. The
    connection underneath is a robust one, so a broker restart is a pause rather
    than an outage: aio-pika reopens the connection, the channels and the
    consumers, and the messages that were unacknowledged when it went are
    redelivered.
    """

    def __init__(self, connection: AbstractRobustConnection) -> None:
        self._connection = connection
        self._admin: AbstractChannel | None = None
        self._publishing: AbstractChannel | None = None
        self._pulling: AbstractChannel | None = None
        self._lock = asyncio.Lock()

    @classmethod
    async def connect(cls, url: str, **kwargs: Any) -> RabbitMQTransport:
        """Opens a connection to a broker.

        :param url: an ``amqp://`` or ``amqps://`` URL
        :param kwargs: passed through to :func:`aio_pika.connect_robust`, which
            is where TLS contexts and client properties are set
        :returns: the transport
        """
        connection = await aio_pika.connect_robust(url, **kwargs)
        return cls(connection)

    @property
    def connection(self) -> AbstractRobustConnection:
        """The aio-pika connection, for anything this library does not wrap."""
        return self._connection

    @property
    def blocked(self) -> bool | None:
        """Whether RabbitMQ has blocked this connection, or ``None`` when unknown.

        A blocked connection is the broker protecting itself from a disk or
        memory alarm, and while it lasts the broker stops reading the socket: a
        publish, a declaration and a health probe all wait instead of failing.
        Knowing that is the difference between waiting for a broker that will
        come back and failing over from one that has gone.

        Read rather than received, because there is nothing to receive it with.
        aio-pika exposes no blocked state and no callback for it; aiormq
        underneath handles ``connection.blocked`` and ``connection.unblocked``
        by clearing and setting one :class:`asyncio.Event` it keeps under a
        name-mangled attribute, and that event is the only record of the state
        anywhere in the stack. So this walks down to it and answers ``None``
        when it is not there — a client that has moved it, a robust connection
        that is between reconnections, a transport that is not RabbitMQ at all.

        ``None`` is not ``False``. A health report that says the connection is
        not blocked because nobody could look is worse than one that says the
        question could not be asked.
        """
        unblocked = self._unblocked_event()
        if unblocked is None:
            return None
        return not bool(unblocked.is_set())

    @property
    def blocked_reason(self) -> str | None:
        """Always ``None`` here: the reason is not kept anywhere to read.

        RabbitMQ does send one — "low on disk space", usually — and aiormq's
        frame handler logs it and drops it rather than storing it on the
        connection. Nor can it be caught as it arrives: the handlers for channel
        zero are bound into a local table when the connection's reader task
        starts, before ``connect()`` has returned to anything that might add
        one, and neither aiormq nor aio-pika offers a hook of its own.

        So the boolean is honest and the reason is absent, which is the pair
        this library can actually stand behind. The property is here rather than
        omitted because :class:`~acemq_amqp.transport.BlockedState` is what the
        other four libraries expose, and because a client release that starts
        keeping the reason should be one method changing rather than an API
        growing.
        """
        return None

    #: aiormq keeps the blocked state in an event under this name, cleared on
    #: ``connection.blocked`` and set again on ``connection.unblocked``. It is
    #: private and name-mangled, and there is no accessor above it.
    _UNBLOCKED = "_Connection__connection_unblocked"

    #: The attributes worth following down to it: on aio-pika 10 the path from
    #: here is ``_connection.transport.connection`` — a ``RobustConnection``, an
    #: ``UnderlayConnection`` and finally aiormq's own. Naming the links rather
    #: than the path means a layer appearing or disappearing costs nothing.
    _LINKS = ("_connection", "transport", "connection")

    def _unblocked_event(self, depth: int = 4) -> asyncio.Event | None:
        """aiormq's unblocked event, found by walking down the clients."""
        seen: set[int] = set()
        frontier: list[Any] = [self]
        for _ in range(depth):
            following: list[Any] = []
            for node in frontier:
                if node is None or id(node) in seen:
                    continue
                seen.add(id(node))
                unblocked = getattr(node, self._UNBLOCKED, None)
                if isinstance(unblocked, asyncio.Event):
                    return unblocked
                following += [getattr(node, link, None) for link in self._LINKS]
            frontier = following
        return None

    async def _admin_channel(self) -> AbstractChannel:
        """The channel declarations go on, made again if it has been killed.

        A refused declaration closes its channel, so this checks rather than
        assumes: the next declaration after a ``PRECONDITION_FAILED`` should
        report the broker's answer to *its* question, not the corpse of the
        previous one.
        """
        async with self._lock:
            self._admin = await _reusable(self._admin) or await self._connection.channel()
            return self._admin

    async def _publish_channel(self) -> AbstractChannel:
        """The channel publishing goes on, with confirms turned on.

        Confirms cost a round trip and are worth it: without them a publish
        succeeds as soon as the bytes reach the socket, which is not the broker
        promising anything, and a service that treats it as one loses messages
        it believes it sent.
        """
        async with self._lock:
            self._publishing = await _reusable(
                self._publishing
            ) or await self._connection.channel(publisher_confirms=True)
            return self._publishing

    @asynccontextmanager
    async def _throwaway_channel(self) -> AsyncIterator[AbstractChannel]:
        """A channel for a question whose answer may be the broker refusing.

        Used where a failure is an expected outcome rather than a problem, so
        that the failure costs nothing but the channel it happened on.
        """
        channel = await self._connection.channel()
        try:
            yield channel
        finally:
            if not channel.is_closed:
                await channel.close()

    async def declare_queue(self, name: str, spec: QueueSpec) -> None:
        channel = await self._admin_channel()
        await channel.declare_queue(
            name,
            durable=spec.durable,
            auto_delete=spec.auto_delete,
            exclusive=spec.exclusive,
            arguments=dict(spec.args) or None,
        )

    async def declare_exchange(self, name: str, spec: ExchangeSpec) -> None:
        channel = await self._admin_channel()
        await channel.declare_exchange(
            name,
            type=spec.kind,
            durable=spec.durable,
            auto_delete=spec.auto_delete,
            arguments=dict(spec.args) or None,
        )

    async def bind(self, queue: str, exchange: str, routing_key: str) -> None:
        channel = await self._admin_channel()
        bound = await channel.get_queue(queue)
        await bound.bind(exchange, routing_key)

    async def publish(
        self, exchange: str, routing_key: str, message: Outbound
    ) -> PublishResult:
        channel = await self._publish_channel()
        # An empty exchange name is the default exchange, which routes to the
        # queue whose name matches the routing key. ensure=False keeps this from
        # declaring anything: publishing is not the place to find out an
        # exchange is missing, because the broker will say so anyway.
        target = (
            channel.default_exchange
            if not exchange
            else await channel.get_exchange(exchange, ensure=False)
        )

        outbound = aio_pika.Message(
            message.body,
            headers=dict(message.headers),
            content_type=message.content_type or None,
            message_id=message.message_id or None,
            # ``None`` rather than an empty string, because AMQP's reply-to is
            # absent or set and "set to nothing" is neither. A responder in
            # another language reads the property and would take "" for an
            # address.
            reply_to=message.reply_to or None,
            delivery_mode=(
                aio_pika.DeliveryMode.PERSISTENT
                if message.persistent
                else aio_pika.DeliveryMode.NOT_PERSISTENT
            ),
        )

        # Typed as object because aio-pika's annotation does not describe what it
        # actually returns: a message the broker sent back as unroutable arrives
        # here as a DeliveredMessage carrying the Basic.Return, not as one of the
        # confirmation frames the signature promises.
        try:
            confirmation: object = await target.publish(
                outbound, routing_key=routing_key, mandatory=message.mandatory
            )
        except DeliveryError as refused:
            # aiormq raises a nack rather than returning it, so the frame the
            # check below looks for never arrived here and a refusal escaped as
            # aiormq's own exception -- past the PublishError the connection
            # raises for a nack, and past every hop that settles on it.
            if type(refused.frame).__name__ != "Nack":
                raise
            return PublishResult(message_id=message.message_id, confirmed=False, routed=True)

        returned = getattr(confirmation, "delivery", None)
        if returned is not None and hasattr(returned, "reply_text"):
            return PublishResult(
                message_id=message.message_id,
                confirmed=False,
                routed=False,
                return_reason=str(returned.reply_text),
            )

        return PublishResult(
            message_id=message.message_id,
            confirmed=type(confirmation).__name__ != "Nack",
            routed=True,
        )

    async def consume(
        self,
        queue: str,
        spec: ConsumeSpec,
        deliver: Callable[[Delivery], Awaitable[None]],
    ) -> _Subscription:
        # A channel of its own, so that one consumer's queue disappearing does
        # not cancel every other consumer on this connection.
        channel = await self._connection.channel()
        if spec.prefetch > 0:
            await channel.set_qos(prefetch_count=spec.prefetch)
        source = await channel.get_queue(queue)
        arguments = dict(spec.args)
        position = _StreamPosition(arguments) if _STREAM_OFFSET in arguments else None

        async def on_message(incoming: AbstractIncomingMessage) -> None:
            await deliver(_delivery(incoming, position))

        tag = await source.consume(
            on_message,
            consumer_tag=spec.tag or None,
            arguments=arguments or None,
        )
        return _Subscription(channel, source, tag)

    async def pull(self, queue: str) -> Delivery | None:
        channel = await self._pull_channel()
        source = await channel.get_queue(queue)
        # fail=False so an empty queue is an answer rather than an exception.
        # no_ack stays off: a pulled message that vanished the moment it was read
        # would make a replay that crashes half way through lose everything it
        # had not yet republished.
        incoming = await source.get(fail=False, no_ack=False)
        return None if incoming is None else _delivery(incoming)

    async def _pull_channel(self) -> AbstractChannel:
        """The channel pulled messages live on.

        Its own, and long-lived, because a pulled message can only be settled on
        the channel it arrived on — and a replay deliberately holds the messages
        it declined unsettled until its pass is over.
        """
        async with self._lock:
            self._pulling = await _reusable(self._pulling) or await self._connection.channel()
            return self._pulling

    async def queue_exists(self, name: str) -> bool:
        # A passive declaration is the only way to ask AMQP whether a queue is
        # there without creating it when it is not, and the answer for a missing
        # queue is the broker closing the channel. Hence a throwaway one.
        async with self._throwaway_channel() as channel:
            try:
                await channel.get_queue(name)
            except ChannelNotFoundEntity:
                return False
            return True

    async def message_count(self, name: str) -> int:
        async with self._throwaway_channel() as channel:
            found = await channel.get_queue(name)
            return int(found.declaration_result.message_count or 0)

    async def delete_queue(self, name: str) -> None:
        channel = await self._admin_channel()
        await channel.queue_delete(name)

    async def close(self) -> None:
        await self._connection.close()


class _Subscription:
    """One running consumer, and the channel it lives on."""

    def __init__(self, channel: AbstractChannel, queue: aio_pika.abc.AbstractQueue, tag: str):
        self._channel = channel
        self._queue = queue
        self._tag = tag

    async def stop(self) -> None:
        """Cancels the consumer, leaving the channel open.

        The cancellation is what makes the promise the consumer above relies on:
        once the broker has acknowledged it, no further delivery will arrive, so
        the workers can be shut down without a message being handed to one that
        has already stopped. The channel stays until they have finished, because
        the messages they are still holding can only be settled on it.
        """
        if not self._channel.is_closed:
            await self._queue.cancel(self._tag)

    async def close(self) -> None:
        """Drops the channel, once nothing on it is unsettled."""
        if not self._channel.is_closed:
            await self._channel.close()


async def _reusable(channel: AbstractChannel | None) -> AbstractChannel | None:
    """A channel this transport kept, once usable again, or ``None`` if it is gone.

    A channel on a robust connection is never dead while the connection lives:
    aio-pika reopens it after the connection drops and after the broker closes
    it for a refused request, and until then ``is_closed`` is true. Opening a
    replacement in that window -- which every publish made during a recovery
    did -- left the old channel registered with the connection, which went on
    reopening it after every reconnection for the life of the process: one more
    channel, on the client and on the broker, per recovery. So a channel that
    is only waiting to be reopened is waited for, and only one that was closed
    for good is replaced.
    """
    if channel is None or cast("asyncio.Future[bool]", channel.closed()).done():
        return None
    if channel.is_closed:
        await channel.ready()  # type: ignore[attr-defined]
    return channel


_STREAM_OFFSET = "x-stream-offset"


class _StreamPosition:
    """How far a stream subscription has got, kept where a recovery reads it.

    A robust queue consumes again after a reconnection with the arguments it
    recorded the first time -- the very dict :meth:`RabbitMQTransport.consume`
    handed it. A queue forgets what it delivered, so that is right for a queue.
    A stream forgets nothing and starts wherever ``x-stream-offset`` says, so
    saying the original thing again replayed a reader that began at "first" from
    the beginning and moved one that began at "next" past everything appended
    while it was away. This keeps the offset in that dict at the oldest entry
    delivered and not yet settled, or just after the newest settled: what a
    queue would redeliver, and nothing it would not.
    """

    def __init__(self, arguments: dict[str, Any]) -> None:
        self._arguments = arguments
        self._pending: Counter[int] = Counter()
        self._settled = -1

    def delivered(self, offset: int) -> None:
        self._pending[offset] += 1
        self._move()

    def settled(self, offset: int) -> None:
        self._pending[offset] -= 1
        if self._pending[offset] <= 0:
            del self._pending[offset]
        self._settled = max(self._settled, offset)
        self._move()

    def _move(self) -> None:
        # ponytail: min() over what is held, which prefetch keeps small
        self._arguments[_STREAM_OFFSET] = (
            min(self._pending) if self._pending else self._settled + 1
        )


def _delivery(
    incoming: AbstractIncomingMessage, position: _StreamPosition | None = None
) -> Delivery:
    """Turns an aio-pika delivery into the transport's own shape."""
    offset = (incoming.headers or {}).get(_STREAM_OFFSET)
    settle: Callable[[], None] = lambda: None  # noqa: E731
    if position is not None and isinstance(offset, int) and offset >= 0:
        # Recorded before the handler sees it and settled before the broker is
        # told, so a reconnection at any point finds it either pending or done.
        position.delivered(offset)
        settle = lambda: position.settled(offset)  # noqa: E731

    async def ack() -> None:
        settle()
        await incoming.ack()

    async def nack(requeue: bool) -> None:
        settle()
        await incoming.nack(requeue=requeue)

    return Delivery(
        body=incoming.body,
        # Kept as None when the sender set none. An empty string would say "the
        # sender told us it was nothing", which is a different claim, and the
        # codecs treat the two differently on purpose.
        content_type=incoming.content_type,
        routing_key=incoming.routing_key or "",
        message_id=incoming.message_id or "",
        headers=dict(incoming.headers or {}),
        redelivered=bool(incoming.redelivered),
        ack=ack,
        nack=nack,
        reply_to=incoming.reply_to or "",
    )
