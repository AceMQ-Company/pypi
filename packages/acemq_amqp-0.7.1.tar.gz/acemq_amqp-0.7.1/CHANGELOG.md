# Changelog

All notable changes to this project are documented in this file. The format
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this
project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

While the version is `0.x` the public API may change in any release.

## [Unreleased]

## [0.7.1] - 2026-09-21

### Changed

- **RabbitMQ 3.13 is now tested rather than assumed.** CI runs the integration
  suite twice on every push, once against 4.x and once against 3.13, each with
  the same two brokers - one speaking plaintext and TLS, one demanding a client
  certificate. Nothing in the library changed: the same sixty tests pass on
  both, including the four that read the negotiated protocol, the cipher and the
  presented chain off the socket, which is the broker's Erlang and therefore
  where a change of broker major would surface first. `README.md` now says 3.13
  or 4.x under Requirements, because a version nothing runs against is a version
  nobody has checked.

### Fixed

- The broker readiness loop bounded `docker logs` with a `date -u` timestamp and
  no zone. Docker reads a naked timestamp as host-local, so anywhere west of UTC
  `--since` hid the very line being waited for and the loop reported a broker
  that had started normally as one that never came up. It worked in CI only
  because runners are UTC.

## [0.7.0] - 2026-09-20

### Added

- **A supported way to ask whether the broker has blocked the connection.**
  `Connection.blocked` and `Connection.blocked_reason`, backed by a new
  `BlockedState` protocol beside `MessageSource` and `QueueAdmin`, which the
  RabbitMQ transport implements. Until now there was nothing: an integration
  wanting the state had to walk `transport → connection → transport →
  connection` looking for a private aiormq attribute by name, which is a path
  that breaks on a client release and takes a health check's ability to tell
  back pressure from a wedged socket with it. `blocked` answers `True`, `False`
  or `None`, and `None` is not `False`: it means the question could not be asked
  — a transport that does not implement the protocol, a connection that has been
  closed — and a report saying `blocked: null` is more use in an incident than
  one saying `false` because nobody looked. It is the shape Java already has as
  `isBlocked()`/`blockedReason()`, .NET as `IsBlocked`/`BlockedReason` and Go as
  `BlockedReason()`.

  **The reason is `None` on RabbitMQ, and that is not an oversight.** RabbitMQ
  sends a reason with `connection.blocked` — "low on disk space", usually — and
  aiormq's handler logs it and drops it rather than keeping it on the
  connection. Nor can it be caught as it arrives: the handlers for channel zero
  are bound into a local table when the connection's reader task starts, before
  `connect()` has returned to anything that might add one, and neither aiormq
  nor aio-pika offers a callback of its own. So the boolean is honest and the
  reason is absent. An invented one would read exactly like a reason the broker
  sent, and the property is there for the client release that starts keeping it.

### Changed

- **The health detail for a blocked connection is now the same sentence every
  AceMQ library writes.** It was *"the broker has blocked this connection,
  usually because it is low on disk or memory. Reported up on purpose…"* and is
  now `the broker has blocked this connection; publishing is paused` — Go's
  `blockedPrefix` and Ruby's `Health::BLOCKED`, word for word. The broker's own
  reason follows a colon rather than sitting in parentheses, which is also what
  those two do.

  **An alert rule matching the old sentence stops matching.** That is the whole
  point of changing it: an operator running services in more than one language
  had to write one rule per language for a condition that is identical in all of
  them, and would have gone on doing so. One sentence, one rule.

  The justification that used to be inside the string — why a blocked connection
  is reported up rather than down — has moved to the comment on
  `BLOCKED_DETAIL` and to `docs/observability.md`. It is a good argument and it
  does not belong in the line somebody reads at three in the morning.

  On RabbitMQ the detail is the prefix alone, because this library cannot
  recover the broker's reason: aiormq logs it and keeps only a flag. See
  `Connection.blocked_reason`.

- **A blocked connection is reported up, with the reason, instead of being
  probed forever.** `Connection.health()` now reads the blocked state before it
  asks the broker anything, carries it in `parts["blocked"]`, and reports
  `UP` for it: a blocked connection is the broker protecting itself from a disk
  or memory alarm, and an application that fails its own readiness check for it
  is one an orchestrator restarts into the same blocked broker, having thrown
  away whatever it was holding. That is the call Java's `AceMqHealthIndicator`
  and Go's check already make. A consumer of this process that has stopped
  reading is still `DEGRADED` while blocked, because that is this instance's own
  failure, it outlives the alarm, and a block is not a reason to stop saying so.

  Nothing in between is allowed a cruder opinion than the connection's, which is
  the flaw worth naming: a built-in check that answered "blocked is degraded"
  would be folded into `aggregate_health`'s worst-of rule and would quietly
  overrule a report that had already decided otherwise. `BrokerHealth` passes the
  connection's own answer through and takes a `timeout` that defaults to three
  seconds against the aggregate's five, so a broker that has gone quiet is
  described by the check that looked rather than by the aggregate giving up on
  it.

- **`Connection.health()` has a deadline.** Its own `HealthCheck` docstring says
  a check must not hang, and it could: the probe is a `queue_exists` round trip,
  and a blocked broker stops reading the socket, so the probe never returns and
  takes the readiness endpoint down with it. Confirmed against a broker under a
  real memory alarm, where a bare `queue_exists` had still not answered after two
  seconds. It now takes a `timeout`, three seconds by default. A probe that runs
  out of time is *abandoned* rather than awaited, because cancelling a request to
  a broker that is not reading means waiting for a cancellation that travels the
  same way the request did; and the blocked state is read again before the
  silence is called a failure, since the notification and the silence arrive
  together. A blocked broker is not probed at all — the answer is already known
  and the round trip would spend the whole deadline arriving at it.

### Fixed

- **Closing a consumer whose workers were already cancelled no longer raises
  `CancelledError` at the caller.** `Consumer.close()` waited on its workers with
  `asyncio.gather`, which re-raises the cancellation of a task that was cancelled
  before closing began — the ordinary shape of a shutdown that cancels the loop's
  tasks and then closes the connection. `Connection.close()` passed it on, so a
  caller inspecting `task.exception()` afterwards was told that *it* had been
  cancelled by something it had asked to shut down. Each worker is now awaited
  with the cancellation swallowed when `task.cancelled()` says the worker was the
  one cancelled. A worker that failed on its own is still reported: the guard is
  on cancellation and nothing else.

- **`send_all`'s `PublishError` no longer ends with a dangling "The first failure
  was: ".** The sentence interpolated the first failure directly, and a failure
  with nothing in its message renders as an empty string — which is exactly what
  the `CancelledError` every send gets when the connection closes underneath the
  batch renders as. The result promised an explanation and stopped. The failure
  is now named by its class when it has no message of its own, so the sentence
  reads `The first failure was: CancelledError`; a failure that has a message is
  unchanged, and still word for word what Java and .NET raise.

## [0.6.0] - 2026-09-17

### Added

- **The docs build now checks the links in `docs/*.md` as well as the ones in
  the rendered site.** The workflow's existing check reads `site/`, which is the
  half of the question it can answer: links between pages are written `.md` and
  rewritten to `.html` for the rendered copy, so a site check is satisfied by
  `guide.html` existing there whatever the markdown said. A cross-page link
  written `.html` in the source renders to a page that works and stays dead in
  GitHub's markdown view — where most people meet these pages first — and no
  site-scoped check can see it. `acemq-java-amqp` carried 75 such links for
  months on exactly that blind spot, found by a reader rather than by CI. The
  new check walks every `](target)` in `docs/*.md`, skips external, `mailto:`
  and pure-fragment links, and requires the rest to exist inside `docs/`; a
  `.html` target that is not the generated `apidocs/` reference is reported as
  "a docs page link belongs in .md" rather than as a missing file, because that
  is the mistake it exists to catch. It runs first in
  `.github/scripts/build-docs-site.sh`, before pandoc and pdoc, since it needs
  nothing rendered and a bad link is cheapest to find before a minute of work.
  This repository's 132 source links passed on the first run.

- **Avro schema resolution is now pinned to the same bytes in all five
  libraries, and documented as one rule rather than five behaviours.**
  `tests/fixtures/avro-resolution-fixtures.json` is generated by
  `acemq-java-amqp` and committed here byte for byte; the workspace's
  `check-fixtures.sh` fails if the copies drift, because a copy that has drifted
  still passes its own suite — it is simply agreeing with the wrong file in
  private. The rule is **resolution happens when the library has a reader schema
  to resolve onto**, and what differs between the languages is only where a
  reader schema comes from: a Go struct carries none, Java is handed one by a
  generated class, and .NET, Python and Ruby construct their codec *with* a
  schema and so have one by default. All five can reach both columns and all
  five assert both; what is only true of Java is that it reaches the writer's
  shape without naming a schema at all, because `registered(registry)` is handed
  none and the writer's schema comes off the wire and serves as the reader's.
  Nothing about the behaviour changed; it was already this, and now it is
  written down and asserted.

  **This library is in the `resolved` column and can reach both.** The fixture
  records each of its two cases decoded under both behaviours, as `resolved` and
  `writerShape`, and `tests/test_avro_resolution.py` asserts Python against both
  — the first from a codec built with the reader's schema, whether through
  `from_registry(...)`, `reader_schema=` or `AvroCodec.reading(...)`, and the
  second by handing the codec the *writer's* schema as its reader schema, which
  is the only way to get there from here. Asserting one column would have pinned
  half of the rule and left the other half a claim in prose.

  The case worth reading is a field the writer removed that the reader declares
  with a default of `"GBP"` — not the empty string, deliberately, because a
  default that is also the type's zero value passes whether resolution happened
  or not. Under resolution the field arrives carrying `"GBP"`; without it the key
  is simply absent. The other case, a field the writer added that the reader does
  not declare, is the one everybody expects to be dangerous and is not: the
  fields the reader declares come back correct either way.

  `docs/serialization.md` gains a **Schema resolution** section, which is the
  same wording in all five repositories down to the language-specific example at
  the end, so a paragraph about it read in one is a paragraph read in all of
  them. The "What is not here" note about schema evolution was quietly wrong and
  is corrected: it read as though `reader_schema=` and `AvroCodec.reading(...)`
  are what switch resolution on, when a plain registry codec resolves too — those
  arguments say which schema to resolve *onto*, not whether to. The section's
  .NET row is corrected in the same pass — the codec is constructed with a schema
  *by default*, and `Registered(registry, schema, readerSchema)` and
  `WithoutReaderSchema()` are how a caller declines it — and the fixture is
  refreshed to the regenerated copy whose `why` lines and `writerShape`
  description say the same. Prose only: the bytes, the cases, the schema ids and
  both columns are unchanged, and every assertion here passed untouched.

  The **Python** and **Ruby** rows are corrected the same way and now match the
  copies in all five repositories. Both said `Always`, which is a stronger claim
  than either library supports: `reader_schema=` here and `reader_schema:` in
  Ruby each move the codec off that default, so the honest word is *by default*.
  Ruby's row had also hidden a second case entirely — `AvroCodec.of` fixes one
  schema for the codec's whole life, reads what it writes, and resolves nothing.
  Python's row stops at "nothing per message to resolve" rather than "reads what
  it writes", deliberately: a fixed-schema `AvroCodec(schema)` can still be
  handed `reader_schema=` in its constructor, and the load-bearing part is that
  it has no registry to learn a writer schema from.

- **Every metric name Java publishes is now written here.** The six that were
  not — `acemq.publish.duration`, `acemq.consume.attempts`,
  `acemq.request.duration`, `acemq.request.total`,
  `acemq.pipeline.run.duration` and `acemq.pipeline.run.total` — were honestly
  documented as absent, with a reason each, which is better than claiming
  compatibility that is not there and worse than being compatible. **A dashboard
  built against a Java, Go or .NET estate now reads against this library panel
  for panel.** The request pair came with the requester and responder counters
  below; these are the other four.

  `acemq.publish.duration` is the timing that was missing beside
  `acemq.publish.total`, and it carries exactly the same labels, deliberately: a
  dashboard dividing one into the other needs both series cut the same way, and
  a duration with a label the total does not have cannot be divided into it. It
  runs from inside `send` to the broker answering, so the codec, the interceptor
  chain, the wait for an outstanding-publish permit and the confirm round trip
  are all inside it — a timer started after the encode would hide a slow codec
  completely. It is recorded whatever the outcome, including a publish that
  raised and a mandatory one that reached no queue, because **the slow publishes
  are the interesting ones** and a timing covering only the successes drops
  exactly those.

  `acemq.consume.attempts` is the number an operator gets earliest. The dead
  letters only move once the attempts run out, so a queue whose messages have
  quietly started needing three tries each looks entirely healthy on every other
  number until the first one gives up. It is recorded when the delivery arrives
  rather than when it is settled: the attempt is a fact about the delivery that
  is true before the handler runs, a body that will not decode is counted too,
  and nothing this consumer is still working on when the process stops is lost.

  **It is the one metric here that is not measured in seconds**, and that has a
  consequence for anybody who has written an `Observer`. Java has a
  `DistributionSummary` for it and a `Timer` for everything else; this interface
  has one `observe`, and adding a second method would break every observer an
  application has already written for the sake of one metric. So the attempt
  count arrives through `observe` with a value of 1, 2, 3. An implementation that
  puts every `observe` into seconds-shaped histogram buckets will report a
  delivery on attempt 2 as a handler that took two seconds and pile the whole
  distribution into the fast end. `PrometheusObserver` gives it buckets of its
  own — `DEFAULT_ATTEMPT_BUCKETS`, whole numbers from 1 to 10, overridable with
  `attempt_buckets=` — so the first bucket answers "how many got it right first
  time" exactly rather than approximately. The `Observer.observe` docstring says
  all of this, because it is the one place somebody writing one will read.

  `acemq.pipeline.run.duration` and `acemq.pipeline.run.total` are written by
  `follow_slip`, from the step that finds no next stop — the step that finished
  the run — so the counter goes up once per run however many services the
  message passed through. They carry `pipeline`, `step` and `outcome`. The
  duration is the **envelope's own age** rather than a timer, and that is the
  whole point of having it: the envelope was created when the message entered
  the pipeline and carried through every hop, so it is the only number that
  spans services. Summing each step's `acemq.consume.duration` misses every
  second the message spent waiting on a queue between two of them, which on a
  busy pipeline is most of the answer.

  **One outcome value is named and never written, and that is deliberate.**
  `OUTCOME_ENDED_EARLY` exists so a dashboard shared with Java can be read
  rather than guessed at, and nothing here emits it: Java writes `ended_early`
  for a pipeline step that returned nothing with stops still to go, and a
  routing-slip `Stage` here always returns the payload for the next stop. There
  is no honest moment to emit it, and emitting `completed` for a run that
  stopped halfway would be a wrong number rather than a missing one. `NOTHING`
  in `then(...)` is the nearest thing and is not the same thing — a `then` chain
  has no pipeline name, no step name and no run to end.

  Java also tags every metric with `message.type` and `transport`, and nothing
  here does, on any metric. That is a narrowing kept from before rather than
  introduced now: `message.type` is producer-controlled and unbounded unless
  somebody is disciplined about it, and `transport` has one value in a library
  with one transport. A Grafana panel filtered on either label matches nothing
  here; everything that does not filter on them reads identically. Both
  `docs/observability.md` and the README say so.

- **A requester and a responder now count what they did, and the caller's round
  trip is a metric.** `responder.answered`, `responder.unanswerable`,
  `requester.timed_out` and `requester.unmatched` are the four numbers Java and
  .NET have always reported and this library reported nowhere;
  `acemq.request.duration` and `acemq.request.total` are the two metric names
  that were documented as absent.

  The gap was real and the documentation was honest about it: `Requester` and
  `serve` are built *over* a connection rather than being something the
  connection knows it is doing, so neither was holding an `Observer` and neither
  had anywhere to put a count. What that left was a page telling an operator to
  read the responder's ordinary consume metrics instead and to write their own
  interceptor if the shape had to match Java's. Both of those work. Neither is a
  round trip: the publish and the reply's delivery are two unrelated hops, and
  **how long asking took has no answer in a picture made of two unrelated hops**.

  **The ordering on `answered` is the contract, not an implementation detail.**
  It is incremented *before* the reply is published, so a caller holding its
  answer can rely on the count already including it. The other order looks more
  natural and is wrong: it leaves a window in which the reply is in the caller's
  hands and the responder still says nothing has been answered, which is a
  dashboard reporting an idle service that is demonstrably working. A publish
  that fails hands the increment back, so this counts replies that were sent
  rather than replies that were attempted — which is the failure incrementing
  early would otherwise introduce, closed in the same place. .NET fixed this
  first, Java followed, and this is Python catching up; all five now promise the
  same thing.

  **The counters exist before the responder subscribes.** A broker may hand the
  first request over from inside the subscribe — which is what a queue with a
  backlog looks like from in here — and the handler reads the counters on that
  very delivery. Java had to say this about field initialisation order and .NET
  had to lift its counters out of the responder to get it; here the handle is
  built before `connection.consume` is called and the handler closes over it. A
  test drives it with a transport that delivers from inside the subscribe.
  Neither number needs a wait before it can be trusted, and code that sleeps
  before reading one is working around a defect that is not here.

  A responder that *failed* counts no answer. The caller is still told, in
  milliseconds rather than at its deadline, but the reply is the thing carrying
  the failure and counting it would let a service that fails every request report
  a perfectly healthy answered rate.

  The two metrics are the **caller's**, and only the caller's.
  `acemq.request.duration` is timed from before the request is published — the caller's wait
  begins there, so the publish is inside the number — to after the reply is in
  hand, and a call that times out is recorded at its deadline, because a p99 that
  quietly drops the slowest calls says a service is fast right up to the point
  where nothing answers at all. Both carry `routing.key` and `outcome`, where the
  outcome is `answered`, `timed_out` or `failed`; `answered` covers a reply that
  came back whatever it said, and `failed` is the publish itself not getting out.
  Java tags the same two with `message.type` and `transport` as well, and this
  does not: no metric here has ever carried either, and a duration labelled
  differently from the total beside it cannot be divided into it.

  **`serve` now returns a `ResponderHandle` rather than a bare `Consumer`.** It
  is closed the same way, is the same `async with`, and reports the same
  `queue`, `running`, `closed` and `in_flight`; `responder.consumer` reaches the
  consumer underneath. The old argument for returning the consumer — that a
  responder owns nothing, so a second class would be one more thing to learn for
  no capability — stopped being true the moment it had counters to own. The name
  is `ResponderHandle` and not Java's `Responder` because that word is taken
  here, by the type alias for what a responder *does*; renaming the alias would
  break every signature written against it for a cosmetic gain.

  **What breaks.** Code that annotated `serve`'s result as `Consumer`, and code
  that reached a `Consumer` method the handle does not forward — `consumer` is
  there for exactly that. `async with await serve(...)` and `await
  (await serve(...)).close()` are unchanged.

- **`max_outstanding_publishes` bounds how many publishes may be waiting for the
  broker at once, and nothing bounded it before.** A thousand by default, which
  is what Java's `maxOutstandingPublishes` and .NET's `MaxOutstandingPublishes`
  have always defaulted to, and the number is the same for the same reason:
  enough to keep a broker busy, small enough that the memory it can cost is
  bounded and obvious.

  What was there instead was a sentence in a docstring. `send_all` created a task
  per payload and let every one of them reach the transport, so a batch held as
  many unconfirmed publishes as the list had entries, and the documentation said
  as much and asked the caller to chunk. That is a defect documented rather than
  fixed. **A caller publishing faster than the broker confirms accumulates
  unconfirmed messages in memory until the process dies, and up to that moment it
  looks like throughput** — the fastest this library has ever appeared to run is
  the hour before it falls over.

  The permit is an `asyncio.Semaphore` on the connection, and it is taken
  **before the message is written** rather than after. A bound applied afterwards
  has already let the message into memory, which is the only thing it was meant
  to prevent. It lives on `Connection.publish_raw`, which is the one place every
  publish in the library passes through — `send`, `send_all`, a retry rung, a
  dead letter, a replay — so one counter covers all of them and no path can quietly
  get round it.

  **Exhausting it is an error rather than a stall.** `confirm_timeout` — ten
  seconds by default, the same as Java's `confirmTimeout` — bounds the wait for a
  permit, and reaching it raises `PublishError` saying which situation this is:

  ```
  1000 publishes are already waiting for a confirm and none completed within
  0:00:10. The broker is not keeping up; publish more slowly rather than
  buffering more.
  ```

  Word for word Java's sentence, so one runbook covers both. A publisher parked
  for ever behind a broker that has stopped answering is indistinguishable from a
  quiet service, and that silence is worse than the failure.

  **The permit is given back on every path out**, including the two that are easy
  to miss: a publish that raises, and a publish whose task is cancelled while the
  broker is still thinking. A permit lost on either of those is a connection that
  publishes a thousand more messages and then deadlocks with nothing anywhere
  saying why, which is a worse failure than the one this fixes.

  `mq.outstanding_publishes` says how many are waiting right now. A number pinned
  at the ceiling is a broker that has stopped answering, and it says so before
  the first `PublishError` does.

  **What to do about it.** Nothing, in almost every case: a service that was not
  already outrunning its broker never reaches the bound and never waits. A
  publisher that deliberately wants a wider window says so —
  `connect(url, max_outstanding_publishes=5000)` — and one that would rather fail
  sooner lowers `confirm_timeout`. `sync.connect` takes both. A batch that used
  to be chunked by hand to keep memory down no longer has to be, though chunking
  a database cursor is still worth doing for the task count.

- **`Publisher.send_all(payloads)` publishes a whole batch before it waits for
  any confirm, and then waits for all of them.** Publisher confirms are on and
  cannot be turned off here, so `send` does not return until the broker has
  answered — which is a round trip per message and exactly what you want for one
  message. For a thousand it is a thousand round trips in a row: on a link with
  5 ms of latency, five seconds of waiting that nothing needed. The batch hands
  every payload to the transport first and awaits the confirms afterwards, so the
  broker is working through the first message while the last is already on the
  wire. **The results come back in the order the payloads were given**, whatever
  order the broker answered in, so a caller can line them up against the list
  they passed.

  Until now the only way to get that in Python was to build the tasks yourself
  and `asyncio.gather` them, which is easy to get subtly wrong: a gather without
  `return_exceptions=True` raises out of the first failure while the rest of the
  batch is still in flight, which throws away the results already collected and
  leaves the other tasks' exceptions unretrieved for asyncio to complain about
  afterwards. That lost count is the expensive part. **A partial batch is the
  ordinary outcome of a broker problem partway through**, and a caller told only
  "it failed" has no choice but to resend everything, duplicating every message
  that had already arrived. `send_all` awaits every send whatever an earlier one
  did, and the `PublishError` that follows names the counts, word for word the
  sentence Java and .NET raise so that one runbook covers all three:

  ```
  2 of 100 messages were not confirmed; 98 were. The first failure was: ...
  ```

  `__cause__` carries the first underlying failure **in payload order** — not the
  first one the broker answered — so a caller that has to tell a broker rejection
  from a confirm timeout still can, and two callers reading the same batch get
  the same answer.

  **This is not atomic and the docstring says so.** AMQP has no way to publish a
  hundred messages such that all or none arrive, and a library that offered one
  would be lying; for a message and the database row it describes to happen
  together, the outbox is still the pattern. How wide a batch gets on the wire is
  capped by the connection's `max_outstanding_publishes` rather than by the list
  it was given — see the entry above — so a list of a million is a million tasks
  and a thousand messages in flight. A million tasks is still a million tasks, so
  chunk what comes out of a database rather than handing a cursor's worth of rows
  to one call.

  **Nothing existing changes.** `send` is untouched, on the wire nothing is
  different from publishing the same messages one at a time, and the blocking API
  gets the same method — `sync` publishers have `send_all` too, running the batch
  on the loop thread and returning when every confirm is in. Java has spelled
  this `sendAll` from the start and .NET `SendAllAsync`; Go and Ruby have no
  equivalent yet.

- **`AvroCodec.reading(...)`, so a consumer can say which schema it was written
  against and have Avro resolve every message onto it.** This is the half of the
  registered mode that was missing, and without it the mode delivered rather
  less than it promised: a codec read every message onto the schema it also
  published with, so a consumer that wanted to read an older or a newer producer
  had to claim a schema identifier it had no business owning and pretend to be a
  publisher to get one.

  What the resolution buys is the thing a schema registry exists for. Given the
  writer's schema alone, a consumer receives whatever the producer sent: a field
  it has never heard of arrives and has to be read past — get that wrong and
  every field after it shifts and decodes as something else — and a field it
  expects is simply absent until the producer starts sending it. Given both
  schemas, Avro resolves them: the unknown field is discarded, the missing one is
  filled in from the reader's own default, and the consumer sees the shape it was
  written against whichever version of the producer wrote the message. **A
  producer can now add a field with a default and deploy before its consumers**,
  which is the whole argument for a registry and was not previously true here.

  A change Avro will not resolve — a field whose type changed under it, a field
  added without a default — raises `FatalError` naming the schema identifier the
  message arrived with, the schema it was being read onto, and Avro's own account
  of what diverged. That failure used to arrive as a generic "this message is not
  Avro this codec reads", which on a queue carrying three producer versions at
  once is not enough to act on.

  Nothing is registered by a reading codec, because a service that only consumes
  writes no schema and has no identifier to frame; `encode` says so rather than
  inventing one. Teach it the writer versions it will meet the way a registered
  codec has always been taught them, with `learn_from(registry, id)` outside the
  message path — the registry here is async and a codec is not.

  **Nothing on the wire changed and nothing needs to be done to existing code.**
  A codec built with `AvroCodec(schema)` or `AvroCodec.from_registry(...)`
  behaves exactly as before, byte for byte and refusal for refusal, and the
  framing stays the one Java, Go, Ruby and .NET read. What to do about it is a
  consumer-side choice: a service that consumes a type it does not publish should
  build its codec with `AvroCodec.reading(my_schema)` instead of inventing a
  schema identifier for itself, and a service that does both can pass
  `reader_schema=` to `AvroCodec.from_registry(...)` and keep one codec. The
  argument is `reader_schema` in every one of those places, which is the spelling
  the whole family has converged on — see the note under **Changed**.

- **`AvroCodec.reader_schema_text`**, the schema every message is resolved onto,
  as text. The same as `schema_text` unless a reader schema was given, which is
  the only case where the two differ.

- **`OutboxRelay` reports what it is doing, so a stopped relay is visible.** It
  counts every record it handles on `acemq.outbox.total`, tagged
  `outcome="published"` or `outcome="failed"`, and times every record it
  publishes on `acemq.outbox.lag` — both through the connection's observer,
  labelled with the record's `exchange` and `routing.key`. Java, Go and .NET
  write the same two names.

  A committed and unpublished row is a message that exists, is owed to somebody,
  and appears in no queue depth anywhere, so until now a relay that had stopped
  read from outside exactly like a service with nothing to send.

  **The lag is measured from the record's own commit**, not from the sweep that
  picked it up. What a lag answers is how long somebody has been owed this
  message, so the wait for a sweep is part of the answer rather than the start of
  it; timed from the sweep, a relay an hour behind reports the same handful of
  milliseconds as one that is keeping up. A commit timestamp built without a
  zone is read as UTC, and a commit clock ahead of the sweeping one reads as zero
  rather than as a negative duration no histogram can hold.

  Nothing has to be wired up: a relay left running under `start()` reports
  without anybody calling `sweep()`. That is the whole point — the span-attribute
  path documented below needs a caller holding a span, and a relay sweeping on
  its own task has none.

- **`METRIC_OUTBOX_TOTAL` and `METRIC_OUTBOX_LAG`** in `acemq_amqp.telemetry`,
  re-exported from the package root, and both carrying a `HELP` line in
  `PrometheusObserver`.

- **Seven documentation pages the site was missing beside Java's and .NET's:**
  `docs/request-reply.md`, `docs/streams.md`, and the four tutorials plus their
  index — `docs/tutorials.md`, `docs/tutorial-first-message.md`,
  `docs/tutorial-surviving-failure.md`, `docs/tutorial-exactly-once.md` and
  `docs/tutorial-observability.md`. The tutorials teach the same four subjects in
  the same order as Java's and .NET's, so somebody arriving from another language
  finds tutorial 3 teaching tutorial 3, and Tutorials is now the accented
  top-level navigation entry in all three sites.

  They are written against **this** library rather than translated from Java's,
  which mattered more than it sounds like it should. Every code sample was run
  against a real broker before it shipped, and doing that turned up four claims
  that a transliteration would have carried across intact:

  - **Java and .NET both document request/reply counters that did not exist
    here.** `requester.timedOut()`, `requester.unmatched()`,
    `responder.answered()` and `responder.unanswerable()` are on both of their
    pages under a heading saying all five libraries promise them identically,
    and Python promised none of them. Writing that down is what made it obvious
    they should simply be written; all four are now here, with the ordering
    guarantee Java and .NET make about `answered` — see **Added** above.
    `docs/request-reply.md` documents what they promise rather than why they are
    missing.
  - **Java's streams page says a stream has no dead-letter queue and that a
    failed message stays where it is.** Here it half does. `read_stream` returns
    an ordinary `Consumer`, so `reject()` republishes a copy to `{stream}.dlq`
    and `park()` to `{stream}.parked` — neither of which touches the log, because
    both of those are ordinary queues beside it. `retry()` *did* publish the
    message back onto the stream, appending a copy every other consumer would
    read; reproduced against a broker with one message and
    `fixed_retry(3, 200ms)`, the log ended up holding attempts 1, 2 and 3 with a
    fourth copy in the dead-letter queue. That is now refused rather than
    documented — see **Changed** below. `docs/streams.md` carries the settlement
    table.
  - **Java's request/reply page says the reply queue carries `x-expires`.** This
    one does not, and does not need to: a generated reply queue is exclusive and
    auto-deleting, so the broker removes it when the connection goes, which
    covers the crash `x-expires` is there for without a timer to tune.
  - **There is no blocking request/reply**, which nothing said. `acemq_amqp.sync`
    has a connection, a publisher and a consumer; a `Requester` waits on an
    `asyncio.Future` per outstanding call, which is the one thing a blocking
    facade cannot hand to a thread that is not on the loop. A blocking
    *responder* can still be written by hand, and the page shows how.

  The tutorials also differ from Java's and .NET's in needing a broker for all
  four rather than for the last two: there is no `memory://` here, because
  `Transport` is a six-method `Protocol` and the fake a test needs is a small
  class rather than a shipped subsystem. Stated up front rather than discovered
  at step 3.

  Where a tutorial publishes several messages it uses `send_all`, and
  `docs/tutorial-observability.md` builds its dashboard only from names this
  library actually writes. That list was six names short of Java's when the
  tutorial was written; all six are written now — see **Added** — and the page
  builds a dashboard from the whole set, with the two caveats that still apply
  called out, because a dashboard is where a wrong panel does the damage.

### Changed

- **"Reader schema" is the name of the idea, everywhere, and
  `AvroCodec.reading(...)` stays.** No API changes: `reader_schema=` keeps its
  spelling, `reading(...)` keeps its name, and nothing on the wire moves. What
  changed is that the docstrings and `docs/serialization.md` now use one name for
  one thing.

  The family has converged on this word — Java's `readerSchema`, Ruby's
  `reader_schema:`, Go renaming to `ReaderSchema`, .NET gaining it — and Python
  already had the spelling. What Python did not have was the *name*: the prose
  called it "the schema this consumer was written against", "the schema every
  message is resolved onto" and "the consumer's own schema" in three different
  places, and the codec's `repr` said `reader=`. Each of those is a correct
  description and none of them is a term, so nothing in the docs could be looked
  up and the paragraph explaining it had to be re-read in every language's page
  rather than recognised. It is now "the reader schema" throughout, with a
  section of that name in `docs/serialization.md` and a `reader_schema=` in the
  `repr`.

  **`AvroCodec.reading(...)` survives, and it is not merely sugar** — which is
  the argument for keeping it. `AvroCodec(my_schema)` is a *fixed-schema* codec
  that writes `avro/binary`; `AvroCodec.reading(my_schema)` is a *registered*
  codec with a reader schema and no identifier to frame, and no combination of
  constructor arguments expresses that, because `schema_id` is what puts a codec
  in registered mode and a read-only codec has none. Removing it would leave the
  consumer-only case with no way to be said at all. It is documented as exactly
  that: `reader_schema` for a service that does not publish, reading precisely
  what `from_registry(..., reader_schema=...)` reads, which a test now pins.

  Java and .NET need no equivalent, and the docs say why rather than listing it
  as a divergence: their registries are synchronous, so one object can hold
  `readerSchema` and still look an identifier up from inside `encode`. The
  registry here is a set of coroutines and a codec is not awaitable, which is why
  this library has two objects where they have one — and `reading(...)` is the
  shorter of the two.

- **`serve(...)` returns a `ResponderHandle` rather than a bare `Consumer`, which
  is source-breaking.** The handle is what carries the responder's counters, so
  it arrived with them — the reasoning, the name and what the handle forwards are
  in the **Added** entry above. Recorded here as well because this is the section
  a reader scans for what a release will not let them compile: code that
  annotated `serve`'s result as `Consumer` needs its annotation changed, and code
  reaching a `Consumer` method the handle does not forward needs
  `responder.consumer`. Nothing on the wire moves, nothing needs to be closed
  differently, and `async with await serve(...)` is unchanged.

- **A stream handler may no longer ask for a retry, and a stream consumer no
  longer inherits one.** `read_stream` refuses `retry(...)` with a new
  `StreamRetryError`, and runs its consumer on `no_retry()` whatever the
  connection's own policy is. **Nothing this library does now appends to a
  stream.**

  What was there before was a footgun that had been carefully documented rather
  than removed. A retry is a republish, and republishing onto a stream
  *appends*: the message goes on the end of the log, where every other consumer
  of that stream reads it as a new one and where it stays for the whole
  retention. One message, `fixed_retry(3, 200ms)` on the connection and a
  handler that always fails left attempts 1, 2 and 3 sitting on the log for ever
  and a fourth copy in `{stream}.dlq`. A projection rebuilt from `from_first()`
  six months later would replay all three.

  It was worse than a knob somebody might reach for, because there was no knob.
  `read_stream` deliberately took no retry policy — and the connection's policy
  reached the consumer anyway, so the damage arrived through a setting made
  somewhere else for a completely different queue. From outside, a stream that is
  growing looks exactly like a stream that is busy.

  **Both doors are now shut.** A handler returning `retry(...)` gets a
  `StreamRetryError` naming the two honest alternatives, and a copy of the
  message goes to `{stream}.dlq` carrying the same sentence:

  ```
  acemq: a handler reading the stream 'events' asked to retry message 0f9c….
  A stream never removes a message, so retrying one means appending a second
  copy of it to the log for every other consumer to read as well. Park it
  instead — park(...) puts a copy in events.parked and leaves the log alone —
  or accept() to checkpoint past it and record the failure yourself.
  ```

  A handler that *raises* is not retried either, which is the half that mattered
  more: an exception is how Python says a thing failed, so most stream retries
  were never asked for in the first place.

  The two alternatives are enough, and the error names them because a failure
  message that only says no is a failure message somebody works around. **Park
  it** and the copy is in a queue somebody drains, with the log untouched.
  **Or checkpoint and move on** — `accept()` advances this consumer's position
  and the failure becomes the handler's to record, which is what most
  projections want, because the message is still on the log and can be read
  again from an earlier offset once whatever broke is fixed. `reject(...)` still
  works and is the same shape as parking; it is not offered as one of the two
  because "this message is bad" is rarely what a stream failure is.

  **Why the consumer is constrained rather than replaced.** Java models this
  with a separate `StreamConsumer` whose failure policy is `STOP` or `SKIP` and
  nothing else, and the obvious move was to port that type. It would have been
  the wrong port, because the two libraries have different things to remove.
  Java's `MessageConsumer` exposes the retry ladder as *configuration*, so a type
  that offered a dead-letter policy for a stream would be a type where half the
  settings are wrong. Python's `Consumer` exposes `queue`, `running`,
  `in_flight` and `close`, every one of which means exactly what it says on a
  stream. The three-outcome settle path comes from the `Ack` a handler returns
  and not from the consumer type, so the constraint belongs where the `Ack` is
  read — and a `StreamConsumer` here would have been a copy of `Consumer` with
  nothing taken away, plus one more class to learn and one more thing that can
  be held after `read_stream` returns.

  **What breaks.** A stream handler that returned `retry(...)` and was relying on
  the append. There is no compatibility shim and there should not be: the old
  behaviour silently corrupted a log, and a service still depending on it wants
  to find out now rather than from a projection that is wrong in a year.
  Nothing else changes — `accept()`, `park()` and `reject()` do what they always
  did, the consumer is the same object, and a stream consumer now declares
  `{stream}.dlq` and `{stream}.parked` and no retry rungs, because it has no use
  for them.

  `docs/streams.md` and `docs/patterns.md` carry the new settlement table.

- **`tracing.outbox_published(...)` is still application-only, and now says why
  that is a smaller limitation than it read as.** The span attribute
  `messaging.acemq.outbox_lag_ms` still cannot be written by the relay —
  `publish_raw` is beneath the interceptor chain and so beneath the `publish`
  span, and `start()` sweeps where nothing is current — but the measurement is no
  longer lost with it, because a metric needs no span to land on. The method
  remains what an application calls from inside a span of its own.

### Fixed

Documentation, all of it a claim the code stopped supporting.

- **The encrypted-body table said this library interoperates with Java and Ruby
  and with nothing else. It interoperates with all four.** The framing table in
  `docs/serialization.md`, the copy of it in `acemq_amqp.codecs.encrypted` and
  the summary in the README all still described the family as it stood before the
  0.5.0 round: Go writing no magic byte and a two-byte key id length, .NET
  writing AES-256-CBC with a 32-byte HMAC-SHA-256. Both moved to this framing in
  that round — `0xAE 0x01 len keyid`, a 12-byte nonce and AES-GCM with a 16-byte
  tag — and all five libraries have written the same bytes since. Nothing here
  changed; the pages describing it did not keep up.

  **This is the kind of error a reader acts on**, which is why it is in the
  changelog rather than quietly corrected. As written, the table told somebody
  deciding whether a .NET producer could feed a Python consumer that it could
  not, and this is the page they would have checked. It could have bought a
  bridging service, or a second content type, or a decision not to encrypt, none
  of which were ever needed.

  What remains true is smaller and is now said as history rather than as the
  present: .NET still *reads* the AES-256-CBC bodies it wrote up to its own
  0.3.0, so a queue filled before the change can be drained by the library that
  filled it. Nothing writes that framing, and no other library has ever read it.
  A body that does not begin `0xAE` is still refused here as what it is — an
  error naming the framing rather than a decryption failure.

  These pages were corrected once already in this round, from naming Java
  alone to naming Ruby beside it, which writes Java's framing byte for byte.
  That pass was right about Ruby and still two libraries short: what it left
  behind was a table saying five libraries write three framings, and the answer
  is that five libraries write one. This entry is the whole correction; the
  earlier half of it is only worth knowing as how the table got here.

- **The metric-name compatibility claim was wider than the truth.** The README
  and `docs/observability.md` both said the names here are Java's `MetricNames`
  and that a dashboard built against one library reads against another, without
  saying that six of Java's names were not written here at all:
  `acemq.publish.duration`, `acemq.consume.attempts`, `acemq.request.duration`,
  `acemq.request.total`, `acemq.pipeline.run.duration` and
  `acemq.pipeline.run.total`. Listing them with a reason each was the fix at the
  time; writing them was the better one, and all six are now written — see
  **Added**. The claim is true as it stands.

- **A relayed message produces no publish span and no `acemq.publish.total`**,
  which nothing said. `publish_raw` puts the committed bytes on the wire
  unchanged — the reason `record(...)` encodes inside the transaction — and both
  the span and the counter live on the encoding path above it. Recorded in
  `docs/observability.md` and `docs/patterns.md`, with `acemq.outbox.total` named
  as the count to read instead.

- **Ruby was missing from a dozen family claims** written when there were four
  libraries: the development-certificate marker and the certificates it stamps,
  the envelope fields, the rung arguments, the tracing system value, the
  acknowledgement vocabulary and the retry acknowledgement's name. All verified
  against `acemq-ruby-amqp` rather than assumed.

- **`park(...)` and `reject(...)` were absent from the README's handler
  vocabulary**, which showed only `accept()` and `retry()`. `park` was added in
  0.5.0 and the README had never named it.

- **The claim check was missing from the storage seams.** The README and
  `docs/patterns.md` both said three patterns have a storage seam; there are
  four, and `ClaimCheckStore` is the one that is synchronous and not in
  `acemq_amqp.patterns.sql`.

- **"Rejecting does not dead-letter" was wrong about streams.** The
  `acemq_amqp.patterns.streams` module docstring and `docs/patterns.md` both said
  a rejected message on a stream is not dead-lettered because there is nothing to
  remove it from. Half of that is right — nothing is ever removed from a stream —
  and the conclusion is not: `read_stream` returns an ordinary `Consumer`, so a
  rejection republishes a copy to `{stream}.dlq` and acknowledges the original,
  exactly as on a queue. A retry appended the message to the stream itself,
  which is the behaviour the **Changed** entry above removes. Both pages now say
  what happens.

- **`Connection.message_count` on a stream was documented as the retained
  count.** `docs/patterns.md` said it reports how many messages are retained
  rather than outstanding. The broker reports **zero**, whatever the stream
  holds, because depth counts messages nobody has taken and on a stream nobody
  ever takes one. The `x-stream-offset` header each delivery carries is what
  answers the question that was being asked, and both pages now say so.

## [0.5.0] - 2026-09-09

### Added

- **A routing slip is read in either of the family's two wire forms, and can be
  written in either.** Python writes the JSON slip, `acemq-routing-slip`, as it
  always has; Java's `Pipeline` writes `x-acemq-route` — the step names,
  comma-separated, with `x-acemq-route-position` and `x-acemq-route-id` beside
  them — resolved against a pipeline declared in advance. Neither could read the
  other, so a Java step and a Python step could not be on the same route.

  `slip_from` now reads whichever the message carries, and `follow_slip` writes
  the same one back, which is what lets a Python step sit in the middle of a
  Java-declared pipeline without either side being told about the other.
  Answering a declared route with a JSON slip would hand the next Java step a
  message with no route on it at all, and the run would stop halfway with
  nothing anywhere saying why — so echoing the form is the default rather than
  an option.

  ```python
  consumer = await mq.consume(
      "fulfilment.enrich", follow_slip(mq, enrich, pipeline="fulfilment")
  )
  ```

  `pipeline=` is the exchange the step names are bound to — the pipeline's own
  name, whose queues are `{pipeline}.{step}` — and it is the one thing the
  declared form does not put on the wire. Writing that form deliberately is
  `route_of("fulfilment", "validate", "enrich", "dispatch")`, or `form=` on
  `start` and `follow_slip`, from the new `SlipForm`.

  **JSON stays the default**, because three of the five libraries write it and
  it is the self-describing one: each step carries its own exchange and routing
  key, so a message can be followed by a service that knows nothing about the
  route, and a route can be built per message. The declared form buys a slip
  readable in a management console and gives up sending a message anywhere the
  declaration does not already know about.

  A slip that cannot be said in the declared form is refused where it is built
  rather than sent somewhere unexpected: steps spanning two exchanges, a step
  with no name, and a step whose name and routing key disagree are each a
  `ValueError`, and a step that raises one on the way out rejects the message
  rather than retrying it — it will not become writable on another attempt.

- **`Envelope.route`, `.route_position` and `.route_id`**, the three reserved
  headers that form carries. Fields rather than application headers for the same
  reason `claim` is one: the names are reserved, so the application map refuses
  them, and a pattern reading one off a delivery had nowhere else to look. They
  are carried by `with_`, so a retry, a dead-letter and a replay all keep them —
  which is what makes replaying a dead-lettered message *resume* its route
  instead of starting it again. Java's `Envelope` carries the same three.

- **`park(error)` joins `accept`, `retry` and `reject` in the handler's
  vocabulary.** It settles the message onto `{queue}.parked`, counts on
  `acemq.messages.dead.lettered.total` with `outcome="parked"`, and puts
  `parked` on the delivery's `process` span.
  The engine could already park — a body its codec refuses goes there before
  any handler runs — but a handler could not ask for it, so one that got a layer
  further in and found a schema it was never taught had to `reject` the message
  into the dead letters and lose the distinction the parked queue exists to
  make. `reject` is *understood, and refused*; `park` is *never understood at
  all*, and mixing the two means whoever drains `{queue}.dlq` has to sort the
  producer emitting rubbish out of the thousands that merely ran out of
  attempts. `Settlement.parked` is the property for it, and
  `Settlement.dead_lettered` is deliberately **false** for a parked message: it
  went to a different queue. Go and Ruby are adding the same word.

- A parked span is **not** an `ERROR`, for the same reason `rejected` is not: it
  is a decision a handler made on purpose. The `parked` outcome on
  `acemq.messages.dead.lettered.total` and the queue itself are what an operator
  watches for those.

- **`Message.reply_to`**, and `reply_to` on `Outbound`, `Delivery`,
  `PublishContext`, `ConsumeContext` and `Publisher.send(...)` — AMQP's own
  `reply-to` property, which this library previously neither wrote nor read.
  See the request-and-reply entry under **Changed**.

- **Payload encryption: `acemq_amqp.codecs.encrypted`, behind the `[crypto]`
  extra.** `EncryptedCodec` wraps any other codec and encrypts what it produced,
  so the broker, its disk, its backups and its management interface hold
  ciphertext. AES-GCM through `cryptography`, a fresh 12-byte nonce per message
  from `os.urandom`, and a 128-bit tag. The framing is
  `0xAE | 0x01 | keyIdLen | keyId | nonce | ciphertext+tag`, and the whole header
  is bound in as associated data, so a key identifier altered in flight makes the
  message fail to open rather than open as something else.

- The key identifier travels **in the clear**, which is what makes rotation
  possible: a consumer reads which key a message needs instead of assuming the
  current one, so a new key can be introduced while messages written with the old
  one are still queued. `key_id_of(body)` answers that question from the bytes
  alone, without holding any key — which is what an operator looking at a
  dead-letter queue they can no longer read actually needs. `Keyring` holds
  several keys with one current; `add` then `use` is the order to rotate in.

- No failure message, log line or `repr` in that module ever contains the
  plaintext, the key, or any part of either, and a wrong key and a tampered body
  produce the identical `FatalError` — GCM authenticates before it returns
  anything, and nothing was added that would tell the two apart. Both properties
  are pinned by tests that sweep every failure path rather than by one assertion
  each.

- **A cross-language divergence, recorded rather than smoothed over.** All four
  libraries write `application/vnd.acemq.encrypted` and four different things
  underneath it. Java uses a `0xAE` magic byte, a one-byte identifier length and
  AES-GCM; Go omits the magic byte and writes a two-byte big-endian length; .NET
  omits the magic byte and uses AES-256-CBC with an HMAC-SHA-256 tag over a
  16-byte IV. **This library implements Java's, byte for byte, and interoperates
  with Java alone** — a Go or .NET body is refused visibly rather than misread.
  Java's is the one to converge on, being the only framing whose first byte
  identifies the format at all. `tests/test_encrypted.py` carries a complete test
  vector — known key, known nonce, known plaintext, exact bytes — to converge
  against, and a body produced by the compiled Java codec that is decrypted here.

- **Development certificates: `acemq_amqp.devcerts`, behind the `[crypto]`
  extra.** `python -m acemq_amqp.devcerts` writes a certificate authority, a
  broker certificate, a client certificate and a `rabbitmq.conf` pointing the
  broker at them — the same file names Go's `acemq-certs` writes, so it is a
  drop-in replacement for it in a script such as `scripts/tls-broker.sh`. ECDSA
  on P-256, thirty days by default, an hour of slack at the front for a
  container's clock, private keys written `0600`.

- **Every certificate carries `ACEMQ DEVELOPMENT ONLY - DO NOT TRUST` in its
  subject organisation, and `acemq_amqp.security` now refuses any certificate
  carrying it — however trust is configured, `without_verifying_the_broker()`
  included.** That is what stops a development certificate reaching production: a
  generated authority's private key sits next to its certificate and usually ends
  up in a repository, so one that could reach production would be an authority
  anybody who can read that repository can issue against, and the connection
  would succeed. Java, Go and .NET stamp the same string and enforce it the same
  way.

- The refusal happens twice, because a development certificate arrives from two
  directions. Files this configuration *names* are checked when the TLS context
  is built, where the error can point at the setting to change; what the broker
  *presents* is checked at the handshake through `SSLContext.sslobject_class`,
  which is the only seam `ssl` offers — there is no verify callback of the sort
  Go's `VerifyPeerCertificate` and Java's `X509TrustManager` give. The handshake
  check reads the encoded certificate rather than a verified chain, because under
  `CERT_NONE` there is no verified chain and that is precisely the configuration
  in which a development certificate is most likely to be reached for.

- `Security(allow_development_certificates=True)` is the way through, named the
  same as in the other three libraries. It counts as a TLS setting, so it is
  refused against an `amqp://` URL alongside the rest.

- `DEVELOPMENT_MARKER` and `is_development_certificate` are exported from
  `acemq_amqp`. The latter reads DER, and reads PEM by decoding it first — the
  marker is plain ASCII inside a DER certificate and nowhere to be seen in the
  Base64 that wraps it, so a PEM file searched as it stands comes back clean
  every time.

- **OpenTelemetry tracing: `acemq_amqp.tracing`, behind the `[opentelemetry]`
  extra.** `OpenTelemetryTracing().install(mq)` registers a publish interceptor
  and a consume interceptor. Written against `opentelemetry-api` and not the SDK,
  which is the package a library is supposed to depend on: without an SDK
  installed and configured by the application, the API's no-op implementation
  runs and nothing is exported.

- **A consumer's span is a child of the publish that caused it**, extracted from
  the message's own headers rather than from ambient context. That join — across
  processes and minutes — is the entire reason to trace a message system, and
  reading the ambient context instead would produce traces that look joined up
  and join the wrong things.

- Trace context travels in `traceparent` and `tracestate`, now in
  `acemq_amqp.headers` and **deliberately not `x-acemq-` prefixed** unlike every
  other name in that module: they are the W3C names other tooling already
  recognises, and prefixing them would have made the context private to AceMQ.
  Java, Go and .NET write the same two.

- Spans are `<destination> publish` (PRODUCER), `<queue> process` (CONSUMER) and
  `<destination> request` (CLIENT). CLIENT for the request because that span
  waits for an answer, so its duration measures a responder rather than a broker.
  Attributes are `messaging.system`, `messaging.destination.name`,
  `messaging.operation`, `messaging.message.id`,
  `messaging.message.conversation_id`,
  `messaging.rabbitmq.destination.routing_key`, `messaging.acemq.message_type`,
  `messaging.acemq.attempt` and `messaging.acemq.outcome` — the same names in all
  four libraries. `unroutable`, `failed` and `dead_lettered` set the span status
  to ERROR; the others, `retried` included, do not.

- `outbox.publish_failed`, `pipeline.run_finished`, `message.retried` and
  `message.dead_lettered` are **events on the current span rather than spans of
  their own**, because a zero-length span at the end of a trace adds a row and no
  information. `propagation_headers()` injects the current context into a fresh
  carrier for a message this library does not publish.

- The tracing tests use the SDK's `InMemorySpanExporter` and assert on spans that
  were really emitted, not on mock calls — a mocked tracer is satisfied by an
  adapter whose spans never end, are never parented and never reach an exporter.
  An integration test proves the same join survives a real broker round trip.

- **The five codecs Java and Go ship: YAML, TOML, XML, Protobuf and Avro.** One
  module each under `acemq_amqp.codecs`, one extra each, and nothing added to the
  core's dependencies. The gap they close is not capability — Python could always
  parse YAML — but interoperability: a Java or Go service publishing any of these
  formats produced a message this library refused, because nothing here claimed
  the content type. The write types are the contract and are the ones the other
  libraries write: `application/yaml`, `application/toml`, `application/xml`,
  `application/x-protobuf`, and `avro/binary` or `application/vnd.acemq.avro`.

- Each codec **reads a wider set than it writes**, because a producer in another
  stack uses whichever spelling its own library picked. YAML also accepts
  `application/x-yaml`, `text/yaml` and `text/x-yaml` — all three predate the
  RFC 9512 registration and are what most tooling still emits — TOML also accepts
  `text/toml`, XML also accepts `text/xml`, Protobuf also accepts
  `application/protobuf`, and every one of them accepts its `+suffix` form. None
  of the five answers for a message with **no** content type; `JsonCodec` remains
  the only codec that does, which is right, because a YAML codec that volunteered
  would return the correct value while recording that a YAML message had arrived.

- The suite proves this against **another language's bytes rather than its own**.
  `tests/fixtures/codec-interop-fixtures.json` holds eleven message bodies
  produced by a Go program calling the same functions `acemq-go-amqp/codec/*`
  calls at the versions its `go.mod` files pin, and by a Java program whose
  Jackson mappers are the bodies of the Java codecs' `defaultMapper()` methods at
  the versions `acemq-java-amqp/pom.xml` declares. A round trip would have proved
  nothing about either. Java and Go turned out to write byte-identical XML and
  byte-identical Avro in both framings; their YAML differs only in list
  indentation and their TOML only in quote style, and both of each pair decode to
  the same value here.

- **`ProtobufCodec` accepts `application/vnd.google.protobuf`, which Java does
  not.** Go's codec accepts it and Java's does not, so a message written with the
  type Google's own tooling emits is read by a Go consumer and refused by a Java
  one standing beside it. The union is taken here: accepting it costs nothing and
  closes the hole in this direction. Java's `ProtobufCodec.canDecode` is the side
  that should change.

- **Avro's two modes are not interchangeable, and each claims only its own
  content type — Java's rule, not Go's.** A registered message carries five bytes
  of Confluent framing that a fixed-schema codec reads as the first field; that
  does not throw, so a codec accepting the other framing hands back a record full
  of silent nonsense. Java's `canDecode` is mode-aware and Go's is not, so a Go
  fixed-schema codec claims `application/vnd.acemq.avro` and mis-decodes it. This
  follows Java. Java and Go do agree on the constants themselves and on the
  framing — one zero byte, four bytes of identifier big-endian, then the body —
  and the fixture proves the bytes match.

- **Where the Avro codec improves on Java rather than copying it**: Java's
  fixed-schema `decode` refuses any body of five bytes or more beginning with a
  zero byte, on the grounds that it might be framed — but a legitimate Avro body
  begins with a zero byte whenever its first field encodes to one, which an empty
  string, a `0`, a `false` and the first branch of a union all do. That rule
  refuses real messages. Here the content type is used first, because it is the
  actual contract and it is on the message; the byte heuristic is kept only for
  the case where the sender said nothing at all, where it is the only signal
  there is.

- **`XmlCodec` needs no extra and refuses every DTD, not configurably.** It is
  written against `xml.etree.ElementTree` and `xml.parsers.expat`, so there would
  be nothing in an `[xml]` extra. External entities are already inert in Python —
  `xml.etree` does not resolve them — but **internal** entity expansion is not:
  the billion-laughs attack needs no network and no readable file, and
  `ElementTree.fromstring` expands it, which was checked against the interpreter
  this library is tested on rather than taken from a table. So rather than
  disabling the individual hazards, expat's `StartDoctypeDeclHandler`,
  `EntityDeclHandler`, `UnparsedEntityDeclHandler` and `ExternalEntityRefHandler`
  each raise, and a body carrying `<!DOCTYPE` is a `FatalError` whatever the DTD
  would have said. `defusedxml` was considered and not used: what it does is turn
  these handlers off, and this turns the same handlers off directly.

- `YamlCodec` loads with `safe_load` and there is no way to ask for anything
  else. PyYAML's default loader builds arbitrary Python objects out of tags like
  `!!python/object/apply`, and a message body is untrusted input.

- `TomlCodec` refuses a payload that is not a mapping, in `encode`, the way Java
  and Go both do — TOML is a table format, and a bare list published as TOML is a
  message nothing can read, discovered by the consumer rather than the publisher.
  Reading uses `tomllib` on 3.11 and later and `tomli` on 3.10; writing uses
  `tomli-w`, because the standard library has no writer.

- Importing `acemq_amqp.codecs.yaml`, `.toml` or `.xml` registers it under that
  name, the way Go's `init()` does, so `codec_by_name("yaml")` works from
  configuration. `protobuf` and `avro` are deliberately not registrable: neither
  format's bytes describe themselves, so a codec needs a message type or a schema
  and a no-argument factory has nothing to hand back.

- `AvroCodec.from_registry` and `learn_from` lift schema resolution out of the
  message path. Java's schema registry is a synchronous interface and Go's takes
  a context, so both can look a schema up from inside `encode`; `SchemaRegistry`
  here is a set of coroutines and `encode` cannot await one. A message carrying
  an identifier the codec has not been taught raises `FatalError` naming the
  identifier rather than guessing at it.

- **Sagas.** `Saga` runs named steps in order and, when one fails, compensates
  the completed ones in reverse — the order the world was changed in, because a
  compensation often depends on state a later step has not yet altered. A step
  may be a coroutine, because a step that publishes a message will be. Two
  behaviours are the pattern rather than an accident of it and are pinned by
  tests: a compensation that itself fails is logged, collected into
  `SagaResult.unresolved` and does **not** stop the others, and a completed step
  with no compensation is skipped rather than treated as an error. `run` returns
  a `SagaResult` instead of raising: `complete`, `compensated`, `failed_at`,
  `failure`, `completed`, `unresolved`, and `has_unresolved` — which is the flag
  to alert on, because everything else a saga reports is recoverable by
  construction and those are effects that happened and were not undone.

- **Scheduled delivery.** `Scheduler` delivers a message later through a ladder
  of five time-to-live queues — an hour, ten minutes, a minute, ten seconds, a
  second — that dead-letter into `acemq.schedule.due`, where the scheduler either
  hops the message down a rung or delivers it. A per-message expiration would be
  simpler and wrong: a classic queue expires messages only at its head, so a
  one-minute message queued behind a four-hour one is delivered in four hours and
  nothing reports it. The whole topology is byte for byte what the Java library
  declares — the `acemq.schedule` direct exchange, `acemq.schedule.{1h,10m,1m,10s,1s}`
  and `acemq.schedule.due`, all classic, every rung carrying exactly
  `x-message-ttl`, `x-dead-letter-exchange` and `x-dead-letter-routing-key`, and
  every queue bound on its own name — so a Python service and a Java service
  scheduling on one broker declare the same queues rather than meeting a
  `PRECONDITION_FAILED`. An integration test declares them from Python and then
  again from a second connection with Java's literal argument table, and proves
  the broker accepts that and refuses a different one.

- The scheduler carries four headers, deliberately without the reserved
  `x-acemq-` prefix — `x-schedule-exchange`, `x-schedule-routing-key`,
  `x-schedule-due-at` (epoch milliseconds, as Java's `Instant.toEpochMilli()`
  writes it) and `x-schedule-content-type`. The payload is encoded once, when it
  is scheduled, and moved as bytes from then on: the control consumer reads with
  `BytesCodec` and never decodes a payload, and the content type travels with it
  so the eventual consumer can still choose a codec. None of the four is passed
  on to the destination.

- The scheduler's control consumer is opened with `declare=False`. A consumer
  declares its dead-letter queues at start-up, which is right for a service queue
  and wrong for a shared one: without it every service running a scheduler would
  leave `acemq.schedule.due.dlq` and `acemq.schedule.due.parked` behind on the
  broker. `schedule_topology()` is public, so a deployment can declare the ladder
  from a migration and run its services with no `configure` permission at all.

- **`ConsumeContext.when_settled(listener)`, and `Settlement` in
  `acemq_amqp.ack`.** What a handler answered is not what happened to the
  message, and until now nothing could tell the difference: an interceptor saw
  the `Ack` and never the consumer's decision. A listener registered here is
  told what the consumer settled on — `acked`, `retried`, `rejected` or
  `dead_lettered`, with the delay it chose or the reason it gave — once, on the
  consumer's task, after the decision and before it is carried out. It returns
  whether anything will ever call it, which is `False` for a chain composed by
  hand with no consumer driving it.

### Changed

- **Every metric is renamed onto Java's vocabulary. This breaks every existing
  Python dashboard.** Java's `MetricNames` in `acemq-amqp-api` is the family's
  vocabulary and Go, Python and Ruby are moving onto it. Python's names were an
  entirely disjoint set: no dashboard could read Python and Java together,
  though `docs/observability.md` said one could — that claim is corrected here
  as well as the names.

  | Old | New |
  |---|---|
  | `acemq.messages.published` | `acemq.publish.total{outcome="confirmed"}` |
  | `acemq.messages.publish.failed` | `acemq.publish.total{outcome="unroutable"}` for a mandatory publish that reached no queue, `{outcome="failed"}` for one that did not reach the broker |
  | `acemq.messages.consumed` | *gone* — the sum of `acemq.consume.total` across its outcomes is how many arrived |
  | `acemq.messages.accepted` | `acemq.consume.total{outcome="acked"}` |
  | `acemq.messages.retried` | `acemq.consume.total{outcome="retried"}`, and `acemq.messages.retried.total`, which keeps its `where` label |
  | `acemq.messages.rejected` | `acemq.consume.total{outcome="rejected"}` |
  | `acemq.messages.dead.lettered` | `acemq.messages.dead.lettered.total{outcome="dead_lettered"}`, and `acemq.consume.total{outcome="dead_lettered"}` |
  | `acemq.messages.parked` | `acemq.messages.dead.lettered.total{outcome="parked"}`, and `acemq.consume.total{outcome="parked"}` |
  | `acemq.handler.duration` | `acemq.consume.duration`, now tagged with the outcome |
  | `acemq.messages.in.flight` | `acemq.consume.in.flight` |
  | `acemq.retry.rung.missing` | unchanged |
  | `acemq.messages.set.aside.failed` | unchanged |

  The shape changes as well as the spelling: **where Python had one counter per
  outcome, there is now one counter with an `outcome` tag**, which is what a
  dashboard wants — a failure rate is a ratio between two series of one metric
  and not a division between two differently-named ones. `acemq.messages.retried.total`
  and `acemq.messages.dead.lettered.total` stay as standalone counters beside
  the tagged one, exactly as Java keeps them: the outcome says what was decided
  about a delivery, the counter says how many messages are going round again or
  have been set aside, and that second number is the one an alert is written
  against.

  `acemq.messages.consumed` has no replacement on purpose. It counted arrivals
  and the others counted settlements, so it always led them by however many
  messages were in flight — two counters for one thing that never agreed. Every
  delivery is now counted exactly once, when it is settled, including a body
  that would not decode.

  **Parking is no longer a metric of its own.** Java had no name for it when
  this began and has one now — it is `acemq.messages.dead.lettered.total` with
  `outcome="parked"`, the same counter a dead-lettering moves — so
  `acemq.messages.parked` and `METRIC_PARKED` are gone. Both are a message this
  queue gave up on, and an operator asking how much a queue is giving up on
  wants one number that can then be split; the split still matters, and the tag
  is what keeps it. `acemq.messages.set.aside.failed` is unchanged and is now
  Java's name too, `target` tag included.

  The constants are renamed with the metrics — `METRIC_PUBLISH_TOTAL`,
  `METRIC_CONSUME_TOTAL`, `METRIC_CONSUME_DURATION`, `METRIC_CONSUME_IN_FLIGHT`,
  `METRIC_RETRIED_TOTAL`, `METRIC_DEAD_LETTERED_TOTAL` — and the tag names and
  publish outcomes are constants too, in `acemq_amqp.telemetry`. The delivery
  outcomes are the `OUTCOME_*` names in `acemq_amqp.ack` that the settlement and
  the span already used, so the counter and the span now carry the same word for
  the same delivery by construction.

- **Dotted tag names are rewritten for Prometheus rather than emitted as they
  are.** `routing.key` and `message.type` are legal tag names in Micrometer and
  OpenTelemetry and illegal label names in Prometheus, which allows
  `[a-zA-Z_][a-zA-Z0-9_]*` and nothing else. `prometheus_text` was rendering
  `acemq_messages_published{routing.key="…"}`, which a scraper rejects *in
  full* — the whole scrape, not the one sample it could not parse — so the
  publish counters were reaching nobody. It now writes `routing_key`.
  `PrometheusObserver` sanitises the names it registers too: a
  prometheus-client old enough to validate label names refuses the collector
  outright, which takes the publisher down at the first message rather than
  under-reporting. Label **values** are untouched: a routing key is where the
  dots mean something.

- **A request now carries its return address twice, and a responder reads
  either.** `Requester.ask` sets AMQP's own `reply-to` property *and* the
  `acemq-reply-to` header to the same queue; `serve` reads the header first and
  falls back to the property. All five libraries do exactly this, in that order.

  Before this, request and reply **did not work across the family at all**.
  Python, Go and Ruby wrote only the header; Java and .NET read only the native
  property. A Java or .NET caller reaching a Python responder had its request
  dead-lettered for carrying no return address, and a Python caller reaching a
  Java responder was never answered. No fixture covered the pair, which is how
  it survived. Writing both and reading either makes all twenty-five
  caller/responder combinations work.

  The header is kept rather than replaced because it is the half that survives a
  service which rebuilds the message; the property is what the other four read.
  Header first is the agreed order, so a request republished under a new reply
  queue by an intermediary goes where the intermediary said. `Message.reply_to`
  exposes the property to a handler writing its own responder, and the transport
  protocol carries it in both directions — `Outbound.reply_to` out,
  `Delivery.reply_to` in. A transport that cannot report it leaves it empty and
  the header path is unaffected.

- **The publish counters are tagged `routing.key`, not `key`.**
  `acemq.messages.published` and `acemq.messages.publish.failed` are labelled
  `exchange` and `routing.key`; the tag used to be `key`. Java and .NET both
  spell the fully-qualified name (`MetricNames.TAG_ROUTING_KEY`), Java is the
  reference, and Go is moving in parallel — so this is Python and Go aligning on
  the name three of the five already used rather than a new invention.

  **This changes a label an existing dashboard may group by.** In Prometheus the
  rendered label goes from `key="order.placed"` to `routing_key="order.placed"`,
  so a query reading `acemq_messages_published{key=...}` or grouping `by (key)`
  needs the name changed. The metric names moved in the same release — see the
  rename onto Java's vocabulary above — so a dashboard is being rewritten
  anyway; the tag is `routing.key` on whichever counter it lands on.

- **The tracer is registered as `org.acemq.amqp` rather than `acemq_amqp`**, and
  the `pipeline.run_finished` event's keys are `pipeline`, `step` and `outcome`
  rather than `messaging.acemq.`-prefixed. Java, Ruby, Go and .NET all write the
  reverse-domain scope name and the bare event keys; Python was the odd one out,
  three to one, and the cost was exactly the thing the naming exists for — spans
  from five libraries did not group under one instrumentation scope, and a query
  that found a pipeline event in one library found it in one library. The span
  *attribute* for an outcome is still `messaging.acemq.outcome`; only the
  event's own keys are bare, which is what the others do.

- **A delivery's `process` span now ends when the consumer decides, not when
  the handler returns**, and takes its outcome from that decision. The backoff
  is deliberately outside it: the consumer announces what it is going to do
  before it does it, so a message waiting five minutes in the consumer no longer
  produces a five-minute handler span.

- **A `request` span now ends with an outcome even when nothing went wrong**:
  `answered` when the reply arrived, `timed_out` when the deadline did, `failed`
  for anything else. Those are the two words Java's `MetricNames` spells and its
  requester writes on the same span. Previously an outcome appeared only on a
  failure, so every round trip that worked carried none at all and "how many
  requests were answered" had nothing to divide by. A timeout is recognised by
  type rather than by message — `RequestTimeoutError` is now a `TimeoutError` as
  well as an `AceMQError`, so `except TimeoutError` catches it and so does
  anything already catching `AceMQError` — and it keeps the `ERROR` status,
  because a caller that never got its answer is not a green span whatever the
  outcome attribute calls it.

- **`messaging.rabbitmq.destination.routing_key` is no longer set on a
  delivery's `process` span.** It is a publish-side attribute in every other
  library — Java's `consumeStarted` is not even handed a routing key, and Ruby's
  process span does not carry one — and Python was the only one writing it. An
  attribute present on one library's spans and absent from the other four's is
  worse than one nobody writes, because a query built around it returns the
  Python services and looks like a complete answer. It is unchanged on the
  `publish` span.

- **`outbox_published` is documented as an application call, and why it cannot
  be a library one.** Java's relay calls its equivalent, so
  `messaging.acemq.outbox_lag_ms` is written by the library there. This one
  cannot: `OutboxRelay` publishes with `Connection.publish_raw`, which is
  beneath the interceptor chain and so beneath the `publish` span, and `start()`
  sweeps on a task of its own where nothing else is current either. An attribute
  has to land on a span, and there is no span for a relayed record to land on. A
  hook wired into the relay would compute a lag on every record and hand it to
  nothing, which is worse than no hook — a number silently dropped looks exactly
  like a number that is zero. The method stays where it works, inside a span the
  caller is holding, which is what an on-demand `sweep()` at the end of a request
  already is. Ruby reached the same conclusion for a related reason.

### Fixed

- **A message that exhausted its attempts carried `outcome='retried'` on its
  span, and never `dead_lettered`.** `message_retried` and
  `message_dead_lettered` existed on `OpenTelemetryTracing` and nothing in the
  library called them; they were hooks an application could reach for and
  nobody knew to. So every message the system ever gave up on was recorded as
  one that would be tried again, and a trace backend queried for dead letters
  came back empty while the dead-letter queue filled up. The consumer now
  records both events itself, on the delivery's own span: `message.retried` with
  the delay the policy actually chose — which is a jittered number that exists
  nowhere else — and `message.dead_lettered` with the reason, alongside an
  outcome of `dead_lettered` and an `ERROR` status. A handler that raised and
  was then given up on carries the exception *and* the outcome, in that order,
  as Java does. An outright rejection still reads `rejected`: it goes to the
  same queue, and the word records that somebody meant it. The same gap was
  open in Go, .NET and Ruby and is being closed in all of them.

- **A retry the broker had to hand back was recorded on the span and counted
  nowhere.** When a consumer's own queue has gone, the message cannot be
  republished and is returned to the broker unacknowledged instead. That is
  still the retry the settlement announced and the `process` span records, and
  it moved no counter at all — the one remaining place where the numbers and the
  trace disagreed about a single delivery. It now increments
  `acemq.messages.retried` with `where='requeued'`, a third value beside
  `consumer` and `broker`; the label *names* are unchanged, so no collector is
  affected. The agreement itself is now a test, run over every way a delivery
  can end: the counter that moves and the outcome on the span are asserted to be
  the same verdict.

  The classification bug that Ruby and .NET carried — counters read from the
  handler's `Ack` rather than from the consumer's `Settlement`, so a message
  that exhausted its attempts incremented *retried* — was never present here.
  `_carry_out` has always switched on the settlement. **These numbers do not
  move**, unlike .NET's, where a dashboard will show retries falling and
  dead-letters rising with no change in service behaviour.

- **`AvroCodec` in fixed-schema mode applied its leading-zero-byte heuristic
  only when the content type was absent, and not when it was present and said
  nothing useful.** A message labelled `application/octet-stream` whose body
  began with `0x00` was decoded as a fixed-schema body, which is how five bytes
  of somebody else's schema identifier get read as the first field and every
  value after it comes back silently wrong. The rule is now exactly the one all
  five libraries follow: a content type naming Avro — `avro/binary`,
  `application/avro`, anything ending `+avro` — is believed whatever the first
  byte is; `application/vnd.acemq.avro` is refused by a fixed-schema codec; and
  only a content type that is absent or names something other than Avro lets the
  zero byte have a vote, where it refuses rather than guesses.

## [0.3.0] - 2026-09-08

### Added

- `declare_where_failures_go(transport, queue, retry)` declares the dead-letter
  and retry half of a queue's topology without declaring the queue itself, which
  is the one arrangement `Topology` cannot describe: it refuses a binding on a
  queue it does not declare, and a consumer must not guess at the source queue.
  It is what `consume()` calls at start-up.

- **The claim check.** `ClaimCheckCodec` wraps any codec, sends a payload of at
  least `DEFAULT_THRESHOLD` (64 KiB) to a `ClaimCheckStore` and puts the key on
  the wire in its place; anything smaller travels inline, unchanged. The framing
  is byte for byte what the Java library writes — `0xAC 0x01 0x00` before an
  inline payload and `0xAC 0x01 0x01` before a bare UTF-8 key — so a document a
  Java service put aside is one a Python service can redeem, and a body neither
  wrote goes to the wrapped codec untouched. `InMemoryClaimCheckStore` and
  `FilesystemClaimCheckStore` implement the seam; `claim_key_of` and
  `is_claim_check` read a body without fetching anything, which is what an
  operator looking at a dead-letter queue wants.
- **Database-backed stores**, in `acemq_amqp.patterns.sql`.
  `SqlIdempotencyStore`, `SqlOutboxStore` and `SqlSchemaRegistry` are the three
  storage seams over a real database instead of a dictionary, written against
  the DB-API 2.0 protocols so the module imports no driver: `sqlite3` works with
  nothing installed and psycopg works with `paramstyle="format"`. The suite
  exercises `sqlite3`; the same checks have been run by hand against PostgreSQL
  17 through psycopg 3 and pass, but are not in the suite because a test needing
  a database server is a test that gets skipped. `create_schema` and
  `schema_ddl` make the tables, or print them for a migration tool to own.
- `SqlOutboxStore.add` writes on a connection the **caller** supplies, and
  neither commits nor closes it, so the outbox insert and the business write
  commit together or not at all — the property `InMemoryOutboxStore` says in its
  own docstring that it does not have. With no transaction to join it raises
  rather than opening a connection of its own.

### Changed

- **A consumer declares the queues it will need when a message fails, before it
  subscribes**: `acemq.dlx`, `{queue}.dlq`, `{queue}.parked` and their two
  bindings, plus `acemq.retry`, the rung queues and the binding home when its
  retry policy has waits the broker holds. `mq.consume(...)` used to declare
  nothing at all and leave every one of those to `Topology`. The union is the
  same once a topology has been applied, so a correctly deployed service sees no
  change beyond a few extra declares at start-up; what it fixes is the service
  deployed *without* one, where a consumer that gave up republished to
  `{queue}.dlq`, the broker could not route it, and the message was discarded
  without a trace. Every declaration carries the arguments `Topology` writes, so
  either order is accepted and neither is a `PRECONDITION_FAILED`. The source
  queue is **not** declared — it belongs to whoever set the service up, and
  `x-dead-letter-exchange` on it can still only be asked for through
  `Topology().queue(name, dead_letter=True)`.
- `mq.consume(..., declare=False)` turns that off, for a login with no
  `configure` permission on the vhost and for a tool draining a queue it does not
  own. `sync.SyncConnection.consume` takes it too. A `Requester` passes it
  itself: a reply queue is a mailbox for one process that never dead-letters
  anything, and declaring for it would leave two durable queues behind per
  restart.
- `acemq.retry.rung.missing` and the fallback to waiting in the consumer stay,
  because a rung can still be absent — a consumer started with `declare=False`
  declares none, and a rung deleted under a running consumer is gone whoever
  made it.
- `idempotent(...)` calls `store.confirm(key)` when a handler accepts, if the
  store has one. A store that hands out a *lease* rather than a fact — so a
  consumer that dies holding a message does not block its redelivery — needs to
  be told when the lease becomes a fact. Duck-typed, so a store without one,
  including `InMemoryIdempotencyStore`, behaves exactly as before.

## [0.2.0] — 2026-09-07

> ### ⚠ Migrating: a retry rung now returns through `acemq.retry`
>
> A rung queue is declared with `x-dead-letter-exchange` set to `acemq.retry`,
> where 0.1.0 used `""` (the default exchange). **A rung that already exists
> with the old argument cannot be redeclared with the new one** — AMQP forbids
> changing a queue's arguments in place, so the declare is refused with
> `PRECONDITION_FAILED`.
>
> This only affects a broker that has already run 0.1.0 with a retry policy
> whose delays reach 30 seconds. Delete the `{queue}.retry.*` queues and let
> them be declared again; they hold nothing but messages waiting to be retried,
> and anything in them at the time is lost, so drain first if that matters.
>
> The change exists because the other four libraries all use `acemq.retry`, and
> two services on one queue that disagree about a rung's arguments cannot both
> consume it.

> ### ⚠ Migrating: a durable queue is now a quorum queue
>
> `Topology().queue(...)` declares a durable queue with
> `x-queue-type: quorum`, where 0.1.0 sent no `x-queue-type` at all and
> therefore got a classic queue. **A queue that already exists as classic
> cannot be redeclared as quorum.** AMQP offers no way to change a queue's type
> in place, so the declare is refused with `PRECONDITION_FAILED` — the broker
> answers `inequivalent arg 'x-queue-type' ... received 'quorum' but current is
> 'classic'` — and the service cannot consume the queue at all.
>
> Draining and recreating the queue is the only way through it. Stop the
> consumers, let the queue empty or move what is on it somewhere else, delete
> it, and let this version declare it again; anything still on the queue when it
> is deleted is lost. A service that cannot do that yet can keep the queue
> classic on purpose with `Topology().queue(name, quorum=False)`, which declares
> exactly what 0.1.0 declared.
>
> `{queue}.retry.{delay}`, `{queue}.dlq` and `{queue}.parked` are **not**
> affected: they stay classic, as they are in Java, so an existing one is
> redeclared without complaint. Nor is any queue that is exclusive,
> auto-deleting or transient — a generated reply queue, a temporary queue —
> because RabbitMQ refuses a quorum queue that is any of those, and one is now
> declared classic without being asked rather than being refused by the broker.
>
> The change exists because Java has declared quorum since it had deployments,
> a queue type is compared as strictly as any other argument, and a Java service
> and a Python service consuming one queue cannot disagree about it.

### Added

- **TLS and credentials.** `amqps://` with the system trust store by default, a
  custom CA, client certificates for mutual TLS, and credentials supplied apart
  from the URL so a password need never be embedded in a connection string.
  `Credentials` does not render its secret in `repr`. Turning verification off
  is reachable only through `without_verifying_the_broker(...)`, which says in
  its own docstring what it surrenders.
- **Interceptors.** One function taking `(context, next)` wraps publishing and
  handling, so logging, tracing and tenancy are written once rather than in
  every handler. A publish interceptor sees the payload before the codec runs;
  a consume interceptor sees the envelope after decoding, and what it leaves is
  what the handler gets.
- **Telemetry and health.** Metric names identical to the Go, Java and .NET
  libraries; an `Observer` protocol with a null default; an in-memory `Metrics`
  and a `prometheus_text()` renderer with no dependencies at all.
  `PrometheusObserver` lives behind a `[prometheus]` extra, as the transport
  lives behind `[rabbitmq]`. `Connection.health()` answers up, down or degraded,
  and its broker check creates nothing.
- **The pattern library**: idempotency, outbox, request/reply, replay, ordered
  handling, consumer groups, routing slips, pipelines, a schema registry and
  stream reading. Each is built out of the public API, so nothing is possible
  with a pattern that is not possible without one.
- **A way to install it.** A release workflow publishing to PyPI through Trusted
  Publishing, and a docs workflow publishing the reference to GitHub Pages.
  Until 0.2.0 the `v0.1.0` tag existed and nobody could install it.

### Changed

- **A rung returns through the named `acemq.retry` exchange** rather than the
  default exchange, with one binding `{queue} -> acemq.retry -> {queue}`, and
  dead letters route through `acemq.dlx`. See the migration note above.
- **A durable queue is declared quorum**, as it is in Java, Go, .NET and Ruby.
  `Topology().queue(..., quorum=False)` still declares a classic one, and a
  queue that is exclusive, auto-deleting or transient stays classic on its own
  because a quorum queue cannot be any of those. The rungs, `{queue}.dlq` and
  `{queue}.parked` stay classic too. `QUEUE_TYPE_ARG` and `QUORUM_QUEUE_TYPE`
  are exported for a caller who needs to write the argument themselves. See the
  migration note above.
- **A replay resets `x-acemq-attempt` to 1** unless told otherwise. A message
  dead-lettered on its last attempt would otherwise be dead-lettered again
  before a handler ever saw it.

### Fixed

- `from acemq_amqp import retry` returned the module rather than the function,
  so calling it raised `TypeError: 'module' object is not callable`. This was
  the shipped behaviour of 0.1.0.
- The sync facade's tests deleted two of the three queues they declared, leaving
  one `{queue}.parked` behind on every run.
