# Copyright 2026 AceMQ.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""What the library is doing, and whether it is still working.

Two questions an operator asks about a service that consumes a queue, and the
library is the only thing that can answer either. How much is going through, how
much is failing and how long a handler takes are numbers nobody outside can see;
whether the connection is really up — as opposed to a socket that is open and
wedged — is a question only something holding the connection can ask.

The metric names are the same in Java, Go, Ruby, .NET and here, so a dashboard
built against one library reads against another. Java publishes them through
Micrometer and .NET through ``System.Diagnostics.Metrics``; Python's standard
library has no metrics interface at all, which is why this module defines a
small one and calls it. Implement :class:`Observer` against Prometheus,
OpenTelemetry, statsd or a log line — or use :class:`Metrics`, which keeps the
numbers in memory and is enough for a health endpoint, a test, or a signal
handler that prints them.

Taking a dependency on a metrics library instead would put every user of this
package on the one it chose. The transport already makes that argument and wins
it: aio-pika is an extra, and so is anything here that needs more than the
standard library.

Health is a :class:`HealthReport` with three states rather than a boolean.
``degraded`` exists because "working, but not as well as it should" is worth an
alert and is not worth taking an instance out of rotation — the replacement will
almost certainly be degraded too.
"""

from __future__ import annotations

import asyncio
import threading
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Protocol, runtime_checkable

#: Publishes, tagged with :data:`TAG_OUTCOME`.
#:
#: One counter with an outcome rather than one counter per outcome, because a
#: dashboard that wants the failure rate wants a ratio of two series of the same
#: metric and not a division between two differently-named ones.
METRIC_PUBLISH_TOTAL = "acemq.publish.total"

#: How long a publish took, in seconds, tagged with :data:`TAG_OUTCOME` and
#: carrying the same labels as :data:`METRIC_PUBLISH_TOTAL`.
#:
#: From calling ``send`` to the broker answering, so it includes the encode, the
#: interceptor chain and the confirm round trip — everything a caller waits for.
#: Recorded whatever the outcome, including a publish that failed and one that
#: reached no queue, because the slow publishes are the interesting ones and a
#: timing that covered only the successes would drop them.
#:
#: The same labels as the total beside it, deliberately: a dashboard dividing one
#: into the other needs both series cut the same way, and a duration with a label
#: the total does not have cannot be divided into it.
METRIC_PUBLISH_DURATION = "acemq.publish.duration"

#: Deliveries that were settled, tagged with :data:`TAG_OUTCOME`.
#:
#: Counted once per delivery, from the settlement rather than from what the
#: handler asked for: a handler asking for a retry it has no attempts left for
#: is dead-lettered, and this says so. The sum across the outcomes is how many
#: messages were handled.
METRIC_CONSUME_TOTAL = "acemq.consume.total"

#: How long a delivery took, in seconds, tagged with :data:`TAG_OUTCOME`.
#:
#: Timed around the interceptors as well as the handler, because what an
#: operator wants to know is how long a message takes to deal with, and an
#: interceptor that opens a transaction is part of dealing with it.
METRIC_CONSUME_DURATION = "acemq.consume.duration"

#: Which attempt a delivery was on when it was handled, as a distribution,
#: labelled :data:`TAG_QUEUE`.
#:
#: Not a duration, and the only metric here that is not. A rising distribution is
#: a dependency in trouble, and it says so earlier than anything else does: the
#: dead letters only move once the attempts run out, so a queue whose messages
#: have started needing three tries each looks entirely healthy on every other
#: number until the first one gives up.
#:
#: Recorded through :meth:`Observer.observe` because that is the only
#: distribution the interface has. Adding a method for it would break every
#: observer an application has already written, for one metric — see the note on
#: :meth:`Observer.observe` for what that means for an implementation.
METRIC_CONSUME_ATTEMPTS = "acemq.consume.attempts"

#: How many messages are in a handler right now, as a gauge. Bounded by prefetch
#: times concurrency.
METRIC_CONSUME_IN_FLIGHT = "acemq.consume.in.flight"

#: Messages sent to a retry queue, or otherwise given another attempt. Labelled
#: ``where``: ``broker``, ``consumer`` or ``requeued``.
#:
#: Kept beside :data:`METRIC_CONSUME_TOTAL` rather than folded into it, exactly
#: as Java keeps it: the outcome on a delivery says what was decided, and this
#: says how many messages are going round again, which is the number an alert is
#: written against.
METRIC_RETRIED_TOTAL = "acemq.messages.retried.total"

#: Messages set aside, tagged with :data:`TAG_OUTCOME`: ``dead_lettered`` for one
#: that ran out of attempts and went to ``{queue}.dlq``, ``parked`` for one that
#: nothing could read and went to ``{queue}.parked``.
#:
#: One counter split by the outcome rather than two metrics, which is what Java
#: settled on: both are a message this queue gave up on, and an operator asking
#: how much a queue is giving up on wants one number that can then be split. The
#: split still matters — a message that failed five times and a message nothing
#: could read are different problems with different answers, and whoever drains
#: the queue should not have to sort them by hand — which is what the tag is for.
METRIC_DEAD_LETTERED_TOTAL = "acemq.messages.dead.lettered.total"

#: Long retries that had to wait in the consumer because the rung queue they
#: were meant to wait on is not on the broker.
#:
#: Worth an alert. Nothing breaks — the message is still retried and the wait
#: still happens — but the reason the rung exists is gone: a consumer restart
#: mid-wait now shortens a five-minute backoff to nothing, and the only other
#: sign of it is one log line on a path nobody is watching.
METRIC_RUNG_MISSING = "acemq.retry.rung.missing"

#: Messages that could not be moved to a dead-letter or parking queue, usually
#: because it was never declared. The message is rejected to the broker instead,
#: which is the last thing between it and nothing. Labelled :data:`TAG_QUEUE` and
#: :data:`TAG_TARGET`.
METRIC_SET_ASIDE_FAILED = "acemq.messages.set.aside.failed"

#: Request and reply round trips, tagged with :data:`TAG_ROUTING_KEY` and
#: :data:`TAG_OUTCOME`: :data:`OUTCOME_ANSWERED`, :data:`OUTCOME_TIMED_OUT` or
#: :data:`OUTCOME_FAILED`.
#:
#: The caller's number, and only the caller's. A responder's side is an ordinary
#: queue and is counted on :data:`METRIC_CONSUME_TOTAL` like any other; what
#: nothing else can see is how long *asking* took, because the publish and the
#: reply's delivery are two unrelated hops and neither of them is the round trip.
METRIC_REQUEST_TOTAL = "acemq.request.total"

#: How long a round trip took, in seconds, carrying the same labels as
#: :data:`METRIC_REQUEST_TOTAL`.
#:
#: Measured as the caller experienced it: from before the request is published to
#: after the reply is in hand, so the publish, the responder's work and the reply
#: coming back are all inside it. A request that times out is recorded too, at
#: its deadline, because a p99 that quietly drops the slowest calls is a p99 that
#: says a service is fast right up to the point where nothing answers at all.
METRIC_REQUEST_DURATION = "acemq.request.duration"

#: Outbox records the relay has handled, tagged with :data:`TAG_OUTCOME`:
#: :data:`OUTCOME_PUBLISHED` or :data:`OUTCOME_FAILED`. Labelled
#: :data:`TAG_EXCHANGE` and :data:`TAG_ROUTING_KEY` as well, because a relay
#: drains one outbox into many destinations and "the relay is behind" is nearly
#: always "the relay is behind *on one exchange*".
METRIC_OUTBOX_TOTAL = "acemq.outbox.total"

#: Routing-slip runs that reached the end of their itinerary, labelled
#: :data:`TAG_PIPELINE`, :data:`TAG_STEP` and :data:`TAG_OUTCOME`.
#:
#: Java's ``acemq.pipeline.run.total``, written from the same place: the step
#: that found no next stop is the step that finished the run, so the counter goes
#: up exactly once per run however many services it passed through.
#:
#: The outcome is always :data:`OUTCOME_COMPLETED` here. Java also writes
#: ``ended_early`` for a step that returned nothing with stops still to go, and
#: this library has no way for a routing-slip step to say that — see
#: :data:`OUTCOME_ENDED_EARLY`.
METRIC_PIPELINE_RUN_TOTAL = "acemq.pipeline.run.total"

#: How old a message was when it left a pipeline, in seconds, carrying the same
#: labels as :data:`METRIC_PIPELINE_RUN_TOTAL`.
#:
#: The *run's* duration and not the step's, which is why it is the envelope's age
#: rather than a timer: the envelope was created when the message entered the
#: pipeline and carried through every hop, so this is the only number that spans
#: services. A per-step timing is :data:`METRIC_CONSUME_DURATION` on each step's
#: own queue, and summing those misses every second a message spent waiting on a
#: queue between two of them — which on a busy pipeline is most of the answer.
METRIC_PIPELINE_RUN_DURATION = "acemq.pipeline.run.duration"

#: How long an outbox record waited between being committed and being published,
#: in seconds. Recorded only for a record that went out, and carrying the same
#: labels as :data:`METRIC_OUTBOX_TOTAL`.
#:
#: **The one number that reveals a stopped relay.** A committed, unpublished row
#: is a message that exists, is owed to somebody, and appears in no queue depth
#: anywhere: publish rates, consume rates and queue depths all read as a system
#: with nothing to send, which is exactly what a system that has stopped sending
#: looks like from outside.
#:
#: Measured from the record's own ``created_at`` — when the transaction that
#: decided the message committed — and not from the start of the sweep that
#: picked it up. The question a lag answers is how long somebody has been owed
#: this message, so the wait for a sweep is part of the answer rather than the
#: start of it; timed from the sweep, a relay that has been down for an hour
#: reports the same handful of milliseconds as one that is keeping up.
METRIC_OUTBOX_LAG = "acemq.outbox.lag"

# ---------- tag names ----------
#
# Dotted, because Micrometer and OpenTelemetry are dotted and these have to be
# the same words in five languages. ``routing.key`` and ``message.type`` are
# both illegal Prometheus label names; :mod:`acemq_amqp.prometheus` and
# :func:`prometheus_text` rewrite the dots to underscores at the point of
# export, which is the only place the restriction applies.

#: The exchange a message was published to, empty for the default exchange.
TAG_EXCHANGE = "exchange"

#: The routing key used, or the queue name when publishing without an exchange.
TAG_ROUTING_KEY = "routing.key"

#: The queue a delivery came from.
TAG_QUEUE = "queue"

#: Where a message was being set aside to when that failed: the dead-letter
#: queue or the parking lot. Bounded by the topology, so it is safe as a tag.
TAG_TARGET = "target"

#: The pipeline a routing-slip run belongs to, which is its exchange. Empty when
#: the run carried a JSON slip that names no pipeline.
TAG_PIPELINE = "pipeline"

#: The step a pipeline run was at when it finished. Bounded by the route, which
#: names a fixed handful of steps, so it is safe as a tag.
TAG_STEP = "step"

#: What happened. The publish outcomes are below; the delivery outcomes are
#: :data:`~acemq_amqp.ack.OUTCOME_ACKED` and its neighbours in
#: :mod:`acemq_amqp.ack`, which are the same words the settlement and the span
#: already use.
TAG_OUTCOME = "outcome"

#: A publish the broker took responsibility for.
OUTCOME_CONFIRMED = "confirmed"

#: A publish that went out with nothing promising anything about it. Publisher
#: confirms were not on.
OUTCOME_PUBLISHED = "published"

#: A mandatory publish the broker had no queue for. The quietest failure AMQP
#: has, and the reason ``mandatory`` is worth setting.
OUTCOME_UNROUTABLE = "unroutable"

#: A publish that did not get to the broker at all.
OUTCOME_FAILED = "failed"

#: A request that got its reply.
OUTCOME_ANSWERED = "answered"

#: A request that reached its deadline with no reply.
OUTCOME_TIMED_OUT = "timed_out"

#: A pipeline run that reached the end of its itinerary.
OUTCOME_COMPLETED = "completed"

#: A pipeline run that stopped before the end of its route because a step chose
#: to stop it. **Nothing in this library writes it**, and the name is here so
#: that a dashboard shared with Java can be read rather than guessed at: a
#: :data:`~acemq_amqp.patterns.Stage` always returns the payload for the next
#: stop, so there is no way for one to end a run early and no honest moment to
#: emit this. :func:`~acemq_amqp.patterns.then` has :data:`NOTHING
#: <acemq_amqp.patterns.NOTHING>` for that, and a ``then`` chain is not a routing
#: slip — it has no pipeline name, no step name and no run to end.
OUTCOME_ENDED_EARLY = "ended_early"


@runtime_checkable
class Observer(Protocol):
    """Told what the library is doing.

    Every method is called on the path a message takes, so none of them may
    block and all of them have to be safe to call from several tasks at once.
    An observer that talks to the network on each call is an observer that makes
    every publish as slow as the network it talks to; buffer, and flush
    somewhere else.

    Nothing here is awaitable, deliberately. A metrics call that could suspend
    would reorder the code around it and turn "count this" into a scheduling
    decision, and no metrics library needs it.
    """

    def count(self, metric: str, delta: int, labels: Mapping[str, str]) -> None:
        """Adds to a counter."""

    def observe(self, metric: str, seconds: float, labels: Mapping[str, str]) -> None:
        """Records one sample of a distribution.

        A duration in seconds for every metric but one. The exception is
        :data:`METRIC_CONSUME_ATTEMPTS`, which is a count of attempts and is
        recorded here because this is the only distribution the interface has —
        Java uses a Micrometer ``DistributionSummary`` for it and a ``Timer`` for
        the rest, and this interface has one method where Java has two.

        The argument keeps its name because renaming it would break every
        observer that passes it by keyword, and because it is a duration in every
        case but that one. An implementation that puts durations into histogram
        buckets should give that metric its own: seconds-shaped buckets over a
        value of 1, 2 or 3 report an attempt count as a handful of very fast
        handlers. :class:`~acemq_amqp.prometheus.PrometheusObserver` does exactly
        that, with :data:`~acemq_amqp.prometheus.DEFAULT_ATTEMPT_BUCKETS`.
        """

    def gauge(self, metric: str, value: int, labels: Mapping[str, str]) -> None:
        """Sets a current value."""


class NullObserver:
    """An observer that does nothing, which is what a connection has by default.

    A real object rather than ``None`` checked for at each call site, because
    the alternative is a branch on every publish and every delivery, and one of
    them is eventually written the wrong way round.
    """

    def count(self, metric: str, delta: int, labels: Mapping[str, str]) -> None:
        return None

    def observe(self, metric: str, seconds: float, labels: Mapping[str, str]) -> None:
        return None

    def gauge(self, metric: str, value: int, labels: Mapping[str, str]) -> None:
        return None


@dataclass(frozen=True, slots=True)
class DurationSummary:
    """What a :class:`Metrics` knows about a timing.

    Deliberately not percentiles. Computing those needs either every sample kept
    or a sketch, and a library that quietly did either would be making a
    decision about memory that belongs to the application.
    """

    count: int = 0
    total: float = 0.0
    fastest: float = 0.0
    slowest: float = 0.0

    @property
    def mean(self) -> float:
        """The average, or zero when nothing has been recorded."""
        return self.total / self.count if self.count else 0.0


class Metrics:
    """An :class:`Observer` that keeps the numbers in memory.

    Enough to serve from a health endpoint, assert on in a test, or print on a
    signal. It is not a substitute for a real metrics system: no histograms, no
    percentiles, and nothing is exported anywhere. :func:`prometheus_text`
    renders what it has for a scraper, which needs no dependency at all.

    Locked rather than relying on the event loop, because the blocking API in
    :mod:`acemq_amqp.sync` runs handlers on a thread pool and a counter read
    from two threads at once is a counter that loses increments.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._counts: dict[str, int] = {}
        self._gauges: dict[str, int] = {}
        self._durations: dict[str, DurationSummary] = {}

    def count(self, metric: str, delta: int, labels: Mapping[str, str]) -> None:
        key = metric_key(metric, labels)
        with self._lock:
            self._counts[key] = self._counts.get(key, 0) + delta

    def gauge(self, metric: str, value: int, labels: Mapping[str, str]) -> None:
        key = metric_key(metric, labels)
        with self._lock:
            self._gauges[key] = value

    def observe(self, metric: str, seconds: float, labels: Mapping[str, str]) -> None:
        key = metric_key(metric, labels)
        with self._lock:
            existing = self._durations.get(key)
            if existing is None:
                self._durations[key] = DurationSummary(1, seconds, seconds, seconds)
                return
            self._durations[key] = DurationSummary(
                count=existing.count + 1,
                total=existing.total + seconds,
                fastest=min(existing.fastest, seconds),
                slowest=max(existing.slowest, seconds),
            )

    @property
    def counts(self) -> dict[str, int]:
        """Every counter, keyed by metric and labels."""
        with self._lock:
            return dict(self._counts)

    @property
    def gauges(self) -> dict[str, int]:
        """Every gauge."""
        with self._lock:
            return dict(self._gauges)

    @property
    def durations(self) -> dict[str, DurationSummary]:
        """A summary per timing: how many, the total, the fastest, the slowest."""
        with self._lock:
            return dict(self._durations)

    def __str__(self) -> str:
        lines = [f"{name} {value}" for name, value in sorted(self.counts.items())]
        lines += [f"{name} {value}" for name, value in sorted(self.gauges.items())]
        lines += [
            f"{name} count={summary.count} mean={summary.mean:.4f}s"
            for name, summary in sorted(self.durations.items())
        ]
        return "\n".join(lines) or "nothing recorded yet"


def metric_key(metric: str, labels: Mapping[str, str]) -> str:
    """A metric and its labels as one string.

    Sorted, so the same labels always give the same key however the mapping was
    built. Unsorted, one counter quietly becomes several that each hold part of
    the answer.
    """
    if not labels:
        return metric
    rendered = ",".join(f'{name}="{labels[name]}"' for name in sorted(labels))
    return f"{metric}{{{rendered}}}"


def prometheus_text(metrics: Metrics) -> str:
    """Renders a :class:`Metrics` in the Prometheus text format.

    Written out rather than through a client library, so a service that only
    wants a scrape endpoint needs nothing installed. The format is small and
    stable: a TYPE line, then samples, with dots in the metric name — and in the
    label names, where ``routing.key`` and ``message.type`` have the same
    problem — replaced by underscores, because Prometheus allows them in
    neither.

    A real registry — exemplars, native histograms, a shared process collector —
    is what :mod:`acemq_amqp.prometheus` is for, and it needs the extra.

    :param metrics: what to render
    :returns: the body of a ``/acemq-metrics`` response
    """
    lines: list[str] = []
    for name, value in sorted(metrics.counts.items()):
        metric, labels = _split_key(name)
        base = _prometheus_name(metric)
        lines += [f"# TYPE {base} counter", f"{base}{labels} {value}"]
    for name, value in sorted(metrics.gauges.items()):
        metric, labels = _split_key(name)
        base = _prometheus_name(metric)
        lines += [f"# TYPE {base} gauge", f"{base}{labels} {value}"]
    for name, summary in sorted(metrics.durations.items()):
        metric, labels = _split_key(name)
        base = _prometheus_name(metric)
        lines += [
            f"# TYPE {base} summary",
            f"{base}_count{labels} {summary.count}",
            f"{base}_sum{labels} {summary.total}",
        ]
    return "\n".join(lines) + ("\n" if lines else "")


def _split_key(key: str) -> tuple[str, str]:
    """A key back into its metric and its labels, both ready for a scraper.

    The label names are rewritten here as well as the metric name, because
    ``routing.key`` and ``message.type`` are no more legal as Prometheus label
    names than a dotted metric name is, and a scrape carrying one is a scrape
    the server rejects in full — the sample it could not parse is not the only
    one lost.
    """
    if "{" not in key:
        return key, ""
    metric, _, labels = key.partition("{")
    return metric, "{" + _prometheus_labels(labels[:-1]) + "}"


def _prometheus_labels(rendered: str) -> str:
    """``routing.key="a.b"`` becomes ``routing_key="a.b"``.

    Names only. A label *value* is where a queue name lives, and queue names
    have dots in them that mean something — rewriting those would report a
    different queue than the one the message came from.

    The parse leans on :func:`metric_key` having written this string: a name, an
    equals sign, then a value between the next two quotes. Anything that does
    not read that way is handed back untouched, because a mangled scrape line is
    worse than an odd one.
    """
    pairs: list[str] = []
    rest = rendered
    while rest:
        name, equals, rest = rest.partition('=')
        if not equals or not rest.startswith('"'):
            return rendered
        value, quote, rest = rest[1:].partition('"')
        if not quote:
            return rendered
        pairs.append(f'{name.replace(".", "_")}="{value}"')
        if rest.startswith(","):
            rest = rest[1:]
        elif rest:
            return rendered
    return ",".join(pairs)


def _prometheus_name(metric: str) -> str:
    return metric.replace(".", "_")


class HealthStatus(str, Enum):
    """How a check turned out."""

    #: Working.
    UP = "up"

    #: Not working. A readiness probe should fail on this.
    DOWN = "down"

    #: Working, but not as well as it should. Worth an alert; not worth taking
    #: the instance out of rotation, because the replacement will almost
    #: certainly be degraded too.
    DEGRADED = "degraded"


@dataclass(frozen=True, slots=True)
class HealthReport:
    """What a check found.

    :param status: up, down or degraded
    :param detail: why, when it is not simply up
    :param checked: when this was worked out, in UTC
    :param parts: whatever the check wants to show — a consumer count, a
        round-trip time, the reports of the checks that were combined
    """

    status: HealthStatus
    detail: str = ""
    checked: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    parts: Mapping[str, Any] = field(default_factory=dict)

    @property
    def healthy(self) -> bool:
        """Whether a readiness probe should pass.

        Degraded passes. An instance that is slow is still an instance that
        works, and taking it out of rotation moves the traffic to one that will
        be just as slow with more of it.
        """
        return self.status is not HealthStatus.DOWN

    def __str__(self) -> str:
        return self.status.value if not self.detail else f"{self.status.value}: {self.detail}"


@runtime_checkable
class HealthCheck(Protocol):
    """Anything that can report on itself.

    The library provides one for the connection; an application adds its own — a
    database, a downstream service — and :func:`aggregate_health` combines them.
    """

    @property
    def name(self) -> str:
        """What this check is called in a combined report."""

    async def check(self) -> HealthReport:
        """The current state.

        It must return quickly and must not raise: a check that hangs makes a
        readiness probe hang with it, and a probe that hangs is a pod that never
        comes back.
        """


async def aggregate_health(*checks: HealthCheck, timeout: float = 5.0) -> HealthReport:
    """Runs every check at once and combines the answers.

    The combined status is the worst of them: one thing being down makes the
    whole report down, because a service that cannot reach its broker is not
    ready however healthy the rest of it is.

    At once rather than in turn, so a slow check does not add its latency to the
    others, and under a deadline, so one that ignores the instruction above
    still cannot hang the probe. A check that times out is reported as down with
    the reason, which is the honest reading: something that will not answer in
    five seconds is not something a request can depend on.

    :param checks: what to ask
    :param timeout: how long to give all of them together
    :returns: the combined report
    """
    if not checks:
        return HealthReport(HealthStatus.UP)

    async def run(check: HealthCheck) -> tuple[str, HealthReport]:
        try:
            return check.name, await check.check()
        except Exception as failure:
            return check.name, HealthReport(
                HealthStatus.DOWN, f"the check itself failed: {failure}"
            )

    tasks = [asyncio.ensure_future(run(check)) for check in checks]
    try:
        done, pending = await asyncio.wait(tasks, timeout=timeout)
    except asyncio.CancelledError:
        for task in tasks:
            task.cancel()
        raise

    parts: dict[str, Any] = {}
    worst = HealthStatus.UP
    reasons: list[str] = []

    for task in pending:
        task.cancel()
    for index, task in enumerate(tasks):
        if task in done:
            name, report = task.result()
        else:
            name = checks[index].name
            report = HealthReport(HealthStatus.DOWN, f"did not answer within {timeout}s")
        parts[name] = report
        if report.status is HealthStatus.DOWN:
            worst = HealthStatus.DOWN
            reasons.append(name)
        elif report.status is HealthStatus.DEGRADED:
            if worst is not HealthStatus.DOWN:
                worst = HealthStatus.DEGRADED
            reasons.append(name)

    return HealthReport(worst, ", ".join(reasons), parts=parts)
